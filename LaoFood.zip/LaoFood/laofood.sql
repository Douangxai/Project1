-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2024 at 08:34 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `laofood`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `id_account` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(15) NOT NULL,
  `pass` varchar(50) NOT NULL,
  PRIMARY KEY (`id_account`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id_account`, `username`, `email`, `phone`, `pass`) VALUES
(1, 'Lattana Douangxai', 'doungxaismn@gmail.com', 827852316, '827ccb0eea8a706c4c34a16891f84e7b'),
(2, 'Vilay Khamphien.', 'khamphien.22it@vku.udn.vn', 12345678, 'b2876a643ff04127980d5cedaf0cc6e0'),
(3, 'Nguyễn Thành Công', 'Congnt.22it@vku.udn.vn', 338988608, '2efe18f2713987721bc776f32cd4a217'),
(4, 'Hoàng Bá Cường', 'Cuonghb.22it@vku.und.vn', 835831464, '3a63c66631d814acb2a34d11c248d9a2'),
(5, 'Nguyễn Thanh Bình', 'nguyenhb.22it@vku.udn.vn', 367095941, '8363653848f6a95f47165fe79268f5cc');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL,
  `tenbaiviet` varchar(255) NOT NULL,
  `tomtat` tinytext NOT NULL,
  `noidung` text NOT NULL,
  `tinhtrang` int(11) NOT NULL,
  `hinhanh` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci AUTO_INCREMENT=2;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `tenbaiviet`, `tomtat`, `noidung`, `tinhtrang`, `hinhanh`, `date`) VALUES
(1, 'Hội thi âm thực Việt Nam - Hàn Quốc', '<p><strong>Trong ng&agrave;y 24/12/2023 Trường Đại học C&ocirc;ng nghệ Th&ocirc;ng tin v&agrave; Truyền th&ocirc;ng Việt - H&agrave;n đ&atilde; tổ chức Hội thi &acirc;m thực Việt Nam - H&agrave;n Quốc</strong></p>\r\n', '<p>Trong ng&agrave;y 24/12/2023 Trường Đại học C&ocirc;ng nghệ Th&ocirc;ng tin v&agrave; Truyền th&ocirc;ng Việt - H&agrave;n đ&atilde; tổ chức Hội thi &acirc;m thực Việt Nam - H&agrave;n Quốc c&oacute; những sinh vi&ecirc;n trong từng c&acirc;u lạc bộ v&agrave; những lưu học sinh L&agrave;o tham gia. Đ&acirc;y l&agrave; một ng&agrave;y quan trọng m&agrave; lưu học sinh L&agrave;o đ&atilde; trao đổi văn h&oacute;a ẩm thực với những loại m&oacute;n &quot;X&ocirc;i L&agrave;o, Gỏi đu đủ, Lạp thịt heo v&agrave; Canh măng&quot;&nbsp;Kết quả lễ hội thi những lưu học sinh L&agrave;o đạt được giải nh&igrave;!!</p>\r\n', 1, 'blog2.jpg', '2024-01-02 11:55:16');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `admin_status` int(11) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci AUTO_INCREMENT=2;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id_admin`, `username`, `password`, `admin_status`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE IF NOT EXISTS `tbl_cart` (
  `id_cart` int(11) NOT NULL,
  `code_order` varchar(10) NOT NULL,
  `id_sanpham` int(11) NOT NULL,
  `soluong` int(11) NOT NULL,
  PRIMARY KEY (`id_cart`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci AUTO_INCREMENT=19;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`id_cart`, `code_order`, `id_sanpham`, `soluong`) VALUES
(1, '7751', 4, 1),
(2, '7751', 1, 1),
(3, '7751', 3, 1),
(4, '7751', 2, 1),
(5, '5113', 4, 1),
(6, '5113', 1, 1),
(7, '5113', 2, 1),
(8, '5113', 3, 1),
(9, '9664', 1, 1),
(10, '9664', 4, 1),
(11, '9664', 3, 1),
(12, '9664', 2, 1),
(13, '5265', 1, 1),
(14, '5265', 4, 1),
(15, '3836', 2, 1),
(16, '3836', 4, 1),
(17, '3836', 1, 1),
(18, '3836', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_danhmuc`
--

CREATE TABLE IF NOT EXISTS `tbl_danhmuc` (
  `id_danhmuc` int(11) NOT NULL,
  `tendanhmuc` varchar(100) NOT NULL,
  `thutu` int(11) NOT NULL,
  PRIMARY KEY (`id_danhmuc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci AUTO_INCREMENT=7;

--
-- Dumping data for table `tbl_danhmuc`
--

INSERT INTO `tbl_danhmuc` (`id_danhmuc`, `tendanhmuc`, `thutu`) VALUES
(1, 'Laap/Gỏi', 1),
(2, 'Nộm/Trộn', 2),
(3, 'Canh/Luộc', 3),
(4, 'Nướng/Chiên', 4),
(5, 'Mộc/Hấp', 5),
(6, 'Đồ uống/Ăn vặt', 6);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE IF NOT EXISTS `tbl_order` (
  `id_order` int(11) NOT NULL,
  `id_account` int(11) NOT NULL,
  `code_order` varchar(10) NOT NULL,
  `order_status` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci AUTO_INCREMENT=6;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id_order`, `id_account`, `code_order`, `order_status`, `address`, `date`) VALUES
(1, 1, '7751', 0, 'Phường Hòa Quý, 470 Đ. Trần Đại Nghĩa, Ký túc xá nhà 1_109', '2024-01-06 21:15:25'),
(2, 3, '5113', 1, 'Phường Hòa Quý, 470 Đ. Trần Đại Nghĩa, Ký túc xá nhà 2_204', '2024-01-07 01:05:00'),
(3, 4, '9664', 1, 'Phường Hòa Quý, 470 Đ. Trần Đại Nghĩa, Ký túc xá nhà 2_401', '2024-01-07 01:08:59'),
(4, 2, '5265', 1, 'Phường Hòa Quý, 470 Đ. Trần Đại Nghĩa, Ký túc xá nhà 1_109', '2024-01-07 01:11:45'),
(5, 5, '3836', 1, 'Phường Hòa Quý, 470 Đ. Trần Đại Nghĩa, Ký túc xá nhà 2_209', '2024-01-07 01:18:20');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_review`
--

CREATE TABLE IF NOT EXISTS `tbl_review` (
  `id` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `summary` varchar(255) NOT NULL,
  `review` text NOT NULL,
  `rating` float NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci AUTO_INCREMENT=5;

--
-- Dumping data for table `tbl_review`
--

INSERT INTO `tbl_review` (`id`, `id_product`, `username`, `summary`, `review`, `rating`, `date`) VALUES
(1, 1, 'Douangxai', 'Tôi thích xôi Lào lắm!!', 'Xôi là món  ăn quan trọng ở nước Lào bởi người ta ăn xôi hàng ngày, khác như nước khác mà ăn cơm thường xuyên cho nên xôi Lào có chất lượng cao, khi ăn món ăn Lào phải có ăn xôi nếu không ăn xôi thì ăn món ăn Lào không đúng cách thật rồi đấy!', 5, '2024-01-05 14:43:10'),
(2, 4, 'Douangxai Lattana', 'Canh măng rất ngon', 'Canh măng là món tôi thích nhất của Lào nó có cay, mặn, ngọt, thơm ngon đầy đủ hết luôn, nếu ai muốn ăn thử món Lào nhưng không biết sẽ ăn cái gì thì tôi khuyên bạn thử ăn canh măng này nhé.', 5, '2024-01-05 19:56:11'),
(3, 4, 'Thanh Bình', 'Ngon nhưng khá cay một chút', 'Món ăn này lần đầu xem không đáng ăn theo mình nhưng sau khi ăn thì nó cũng ngon mà nó có vị khá cay theo mình, nếu giảm ớt một chút thì tốt.', 5, '2024-01-05 23:17:40'),
(4, 4, 'khamphien', 'Tôi rất thích canh măng của quán này!', 'Ở Việt Nam khá ít bán món ăn Lào, những quán có bán lại thấy chỉ món nướng-chiên-Lạp nữa muốn tìm canh măng được thì rất khó và tìm canh măng có đây đủ thành phần thì khó 10 lần nữa bởi vì nhiều cái không có ở Việt Nam, nhưng quán này có khá đầy đủ nên tôi cho 5 sao luôn !!!.', 5, '2024-01-06 22:49:44');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sanpham`
--

CREATE TABLE IF NOT EXISTS `tbl_sanpham` (
  `id_sanpham` int(11) NOT NULL,
  `tensanpham` varchar(250) NOT NULL,
  `giasp` varchar(50) NOT NULL,
  `hinhanh` varchar(50) NOT NULL,
  `tomtat` tinytext NOT NULL,
  `noidung` text NOT NULL,
  `tinhtrang` int(11) NOT NULL,
  `id_danhmuc` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  PRIMARY KEY (`id_sanpham`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci AUTO_INCREMENT=27;

--
-- Dumping data for table `tbl_sanpham`
--

INSERT INTO `tbl_sanpham` (`id_sanpham`, `tensanpham`, `giasp`, `hinhanh`, `tomtat`, `noidung`, `tinhtrang`, `id_danhmuc`, `category`) VALUES
(1, 'Xôi Lào', '10000', 'tip khao.jpg', 'Ăn món ăn Lào nếu không ăn xôi thì ăn không đúng kiểu rồi, mua nào ăn cho sướng', 'Ăn món ăn Lào nếu không ăn xôi thì ăn không đúng kiểu rồi, mua nào ăn cho sướng', 1, 5, 1),
(2, 'Nộm đu đủ', '25000', 'papaya-salad.jpg', 'Nộm đu đủ thức ăn tryền thông của Lào', 'nội dung', 1, 2, 1),
(3, 'Laap thịt heo', '30000', 'larb moo.webp', 'Món ăn giải nhì khi vào tổ chức năm ngoái mời anh chị mua ngay rẻ thế', 'Món ăn giải nhì khi vào tổ chức năm ngoái mời anh chị mua ngay rẻ thế', 1, 1, 1),
(4, 'Canh măng', '30000', 'Bamboo-Soup.jpg', 'Canh măng món ăn ngon nhất của nhà hàng, chấp nhận băng cô Linh', 'Canh măng món ăn ngon nhất của nhà hàng, chấp nhận băng cô Linh', 1, 3, 1),
(5, 'Laap Bò', '50000', 'Beef Larp.jpg', 'Laap thịt bò ngon ngon ', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolores ea, provident atque enim laudantium beatae aut a vitae quaerat doloribus at soluta voluptates eius deleniti nobis modi, sapiente alias voluptas?\r\nLorem, ipsum dolor sit amet consectetur adipisicing elit. Cumque nemo cupiditate ipsam fugiat ipsum perspiciatis ab aspernatur ad amet provident ullam distinctio, recusandae omnis aperiam deserunt natus reiciendis maxime dicta?\r\nExplicabo magnam voluptas obcaecati repudiandae vero animi, tempora vel at accusantium, deserunt vitae ipsam, minima doloremque labore odit accusamus earum harum. Magni a hic quae quis accusamus accusantium assumenda enim.\r\nConsectetur iure consequatur assumenda nulla error nisi ducimus illum pariatur. Error omnis, similique dolorum quaerat nostrum earum iure, debitis amet veritatis accusantium aliquid. Facilis doloremque deleniti libero dolore repellendus! Neque.', 0, 1, 1),
(6, 'Gà nướng', '30000', 'chicken grill.jpg', '<p>G&agrave; nướng m&oacute;n ăn đặc sắc của nhiều huyện nhiều tỉnh ở b&ecirc;n L&agrave;o&nbsp;</p>\r\n', '<p>G&agrave; nướng m&oacute;n ăn đặc sắc của nhiều huyện nhiều tỉnh ở b&ecirc;n L&agrave;o chẳng hạn ở tỉnh Salavan c&oacute; g&agrave; nướng Napong, ở Savanhnakhet c&oacute; g&agrave; nướng Seno...</p>\r\n', 1, 4, 1),
(7, 'Laap cá sống', '35000', 'Larp Pa Dip.jpg\r\n                        ', '<p>Laap c&aacute; c&oacute; cả kiểu sống v&agrave; kiểu ch&iacute;n nếu bạn kh&ocirc;ng th&iacute;ch kiểu sống c&oacute; thể t&igrave;m được kiểu ch&iacute;n nh&eacute;.</p>\r\n', '<p>Laap c&aacute; sống cả cay cả ngon, m&oacute;n ăn phổ biến b&ecirc;n L&agrave;o. Laap c&aacute; c&oacute; cả kiểu sống v&agrave; kiểu ch&iacute;n nếu bạn kh&ocirc;ng th&iacute;ch kiểu sống.</p>\r\n', 0, 1, 1),
(8, 'Mộc măng', '20000', 'Mok naw mai.jpg', '<p>Mộc măng ngon ngon ăn dễ d&agrave;ng ph&ugrave; hợp với tất cả mọi mua ngay ăn thử.</p>\r\n', '<p>Mộc l&agrave; một loại m&oacute;n hấp với l&aacute; chuối của b&ecirc;n L&agrave;o tất cả để l&agrave;m m&oacute;n n&agrave;y l&agrave; đến từ tư nhi&ecirc;n n&ecirc;n m&oacute;n n&agrave;y l&agrave; m&oacute;n cả ngon v&agrave; tốt cho sức khỏe.</p>\r\n', 1, 5, 1),
(9, 'Trộn măng', '25000', 'Soob nor mai.jpg', '<p>Trộn hay trong tiếng L&agrave;o gọi l&agrave; &#39;S&uacute;p&#39; l&agrave;m người nước ngo&agrave;i thường thắc mắc với bởi n&oacute; c&oacute; tiếng gọi giống như tư &#39;Soup&#39; của tiếng Anh</p>\r\n', '<p>L&agrave;o c&oacute; nhiều loại m&oacute;n ăn kh&aacute;c nhau theo c&aacute;ch nấu mỗi m&oacute;n ăn c&oacute; t&ecirc;n ri&ecirc;ng của n&oacute; khi dịch sang tiếng kh&aacute;c th&igrave; n&oacute; kh&ocirc;ng đ&uacute;ng lắm. M&oacute;n &#39;s&uacute;p n&ograve; mạy&#39; khi dịch sang tiếng Anh n&oacute; sẽ th&agrave;nh &#39;Bamboo shoot salad&#39; hay l&agrave; &#39;gỏi măng&#39; theo tiếng Việt nhưng v&igrave; b&ecirc;n L&agrave;o cũng c&oacute; m&oacute;n gỏi v&agrave; n&oacute; cũng c&oacute; t&ecirc;n ri&ecirc;ng kh&aacute;c nhau nữa n&ecirc;n n&oacute; kh&ocirc;ng đ&uacute;ng lắm nếu m&oacute;n n&agrave;o cũng sẽ gọi l&agrave; m&oacute;n gỏi hết. N&ecirc;n cửa h&agrave;ng n&agrave;y gọi &#39;Trộn Măng&#39; cho n&oacute; dễ.</p>\r\n', 1, 2, 1),
(10, 'Gỏi cá', '20000', 'Goi Pa.jpg\r\n                        ', 'Gỏi cá thức ăn tryền thông của Lào', 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolores ea, provident atque enim laudantium beatae aut a vitae quaerat doloribus at soluta voluptates eius deleniti nobis modi, sapiente alias voluptas?\r\nLorem, ipsum dolor sit amet consectetur adipisicing elit. Cumque nemo cupiditate ipsam fugiat ipsum perspiciatis ab aspernatur ad amet provident ullam distinctio, recusandae omnis aperiam deserunt natus reiciendis maxime dicta?\r\nExplicabo magnam voluptas obcaecati repudiandae vero animi, tempora vel at accusantium, deserunt vitae ipsam, minima doloremque labore odit accusamus earum harum. Magni a hic quae quis accusamus accusantium assumenda enim.\r\nConsectetur iure consequatur assumenda nulla error nisi ducimus illum pariatur. Error omnis, similique dolorum quaerat nostrum earum iure, debitis amet veritatis accusantium aliquid. Facilis doloremque deleniti libero dolore repellendus! Neque.', 1, 1, 1),
(11, 'Bia Lào', '20000', 'beer.jpg', 'Bia Lào, bia ngon thưởng vàng', 'Bia Lào', 1, 6, 2),
(12, 'Nước suối', '10000', 'water.webp', 'Nước suối Lào, rẻ sạch uống giải khát', 'Nước suối Lào', 0, 6, 2),
(13, 'Cà phê Dao', '15000', 'coffee.jpg', 'Cà phê Dao, Cà phê Lào. Ngon thơm cà phê', 'Cà phê Dao', 1, 6, 2),
(14, 'Laap vịt', '30000', 'Larp Pet.jpg', 'Laap vịt món ăn phổ biến ở bên mua ngay', 'Laap vịt món ăn phổ biến ở bên mua ngay', 1, 1, 1),
(15, 'Gỏi tôm sống', '25000', 'Koi Koung.jpg', 'Gỏi tôm gỏi tép sống sướng cả bụng cả long', 'Gỏi tôm gỏi tép sống sướng cả bụng cả long', 0, 1, 1),
(16, 'Gỏi ốc', '20000', 'Koi Hoi.jpg', 'Gỏi ốc món ăn quê hướng tìm được dễ dàng nhưng bên nào sẽ giống như gỏi ốc kiểu Lào là anh chị ơi!', 'Gỏi ốc món ăn quê hướng tìm được dễ dàng nhưng bên nào sẽ giống như gỏi ốc kiểu Lào là anh chị ơi!', 0, 1, 1),
(17, 'Canh nấm', '25000', 'canh nam.jpg', '<p>Canh nấm L&agrave;o c&oacute; g&igrave; kh&aacute;c với canh nấm Việt Nam mua ngay ăn thử.</p>\r\n', '<p>Mỗi đất nước đều c&oacute; l&agrave;m canh nấm với kiểu ri&ecirc;ng của m&igrave;nh kh&aacute;c nhau, Canh nấm L&agrave;o cũng c&oacute; l&agrave;m kiểu L&agrave;o h&atilde;y mua ngay để thử m&oacute;n ăn của ch&uacute;ng ta</p>\r\n', 1, 3, 1),
(18, 'Laap cá chín', '35000', 'Fish Laap.jpg', '<p>Laap c&aacute; c&oacute; cả kiểu sống v&agrave; kiểu ch&iacute;n nếu bạn c&oacute; thể t&igrave;m kiếm dễ d&agrave;ng để tự chọn kiểu m&igrave;nh mong muốn nh&eacute;!.</p>\r\n', '<p>Laap c&aacute; sống cả cay cả ngon, m&oacute;n ăn phổ biến b&ecirc;n L&agrave;o. Laap c&aacute; c&oacute; cả kiểu sống v&agrave; kiểu ch&iacute;n nếu bạn kh&ocirc;ng th&iacute;ch kiểu sống.</p>\r\n', 1, 1, 1),
(19, 'Xôi xoài', '30000', 'xoi xoai.jpg', 'Xôi xuồi ngon miệng ngọt lưỡi no bụng', 'Xôi xuồi ngon miệng ngọt lưỡi no bụng', 0, 6, 3),
(20, 'Cơm lam', '15000', 'Khao lam.jpg_large', 'Cơm lam mà làm từ xôi ngọt ngạo no bụng', 'Cơm lam mà làm từ xôi ngọt ngạo no bụng', 0, 6, 3),
(21, 'Bánh chứng Lào', '5000', 'Khao-tom.webp', '<p>B&aacute;nh chứng L&agrave;o l&agrave;m bằng gạo nếp như b&aacute;nh chứng Việt Nam nhưng b&ecirc;n trong thường xuy&ecirc;n c&oacute; chuối, đậu đỏ, đậu đen,&nbsp;đậu n&agrave;nh,... theo người l&agrave;m mong muốn', '<p>B&aacute;nh chứng l&agrave; m&oacute;n ăn tr&aacute;ng miệng m&agrave; người L&agrave;o thường l&agrave;m để đi ch&ugrave;a cho c&aacute;c nh&agrave; sư, n&oacute; sẽ c&oacute; vị ngọt ngon miệng ph&ugrave; hợp với tất cả mọi người</p>\r\n', 0, 6, 3),
(22, 'Mọc cá', '25000', 'Mok pa.jpg', '<p>Giống như m&oacute;n c&aacute; kh&aacute;c tiệm n&agrave;y thường xuy&ecirc;n c&oacute; gi&aacute; 20.000 - 35.000 VND kh&ocirc;ng đắt g&igrave; cả mời mua ngay đi!</p>\r\n', '<p>M&oacute;n mộc c&aacute; thơm thơm ngon ngon bởi v&igrave; hấp với l&aacute; chuối, m&oacute;n ăn truyển thống của L&agrave;o mua ngay lập tức!!</p>\r\n', 1, 5, 1),
(23, 'Gỏi trứng kiến', '20000', 'raw-red-ant-eggs-salad.jpg', '<p>Gỏi trứng kiến m&oacute;n ăn truyền thống của b&ecirc;n L&agrave;o, c&oacute; vị chua cay ngon đầy đủ xuất sắc !!</p>\r\n', '<p>Gỏi trứng kiến l&agrave; m&oacute;n ăn k&oacute; t&igrave;m ở thường bởi v&igrave; n&oacute; phải l&agrave;m từ trứng kiến đỏ, phải t&igrave;m n&oacute; trong rưng n&uacute;i kh&ocirc;ng thể t&igrave;m được dễ d&agrave;ng trong th&agrave;nh phố n&ecirc;n gi&aacute; cả sẽ đắt một x&iacute;u.</p>\r\n', 0, 1, 1),
(24, 'Canh lá muồng trâu', '20000', 'canh khi lek.jpg', '<p>Canh l&aacute; muồng tr&acirc;u tuy thấy lạ nhưng m&agrave; ngon đấy ăn thử rồi sẽ th&iacute;ch!</p>\r\n', '<p>Bởi v&igrave; h&igrave;nh thấy lạ v&agrave; kh&ocirc;ng đẹp mắt lắm n&ecirc;n nhiều người thường bỏ qua m&oacute;n n&agrave;y, nhưng thật sự m&oacute;n n&agrave;y l&agrave; m&oacute;n đặc biệt kh&oacute; t&igrave;m ở b&ecirc;n L&agrave;o, người L&agrave;o th&iacute;ch ăn m&oacute;n n&agrave;y bởi n&oacute; rất ngon v&agrave; tốt cho sức khỏe. Ăn thử đi chắc chắn bạn sẽ th&iacute;ch!!</p>\r\n', 0, 3, 1),
(25, 'Laap bò sống', '40000', 'Laap Seen.jpg', 'Laap bò có loại chín loại sống để chọn ăn ngon cả hai loại', 'Laap bò có loại chín loại sống để chọn ăn ngon cả hai loại', 0, 1, 1),
(26, 'Xúc xích Lào', '20000', 'Sausage.jpg', '<p>X&uacute;c x&iacute;ch L&agrave;o ngon thơm no bụng, h&atilde;y mua n&agrave;o!</p>\r\n', '<p>Trong thế giới c&oacute; nhiều loại x&uacute;c x&iacute;ch, mơn mua ăn x&uacute;c x&iacute;ch L&agrave;o ngon qu&ecirc;n thế giới</p>\r\n', 1, 4, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD UNIQUE KEY `email` (`email`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
