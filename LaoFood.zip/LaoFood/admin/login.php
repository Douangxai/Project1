<?php
    session_start();
    include('config/config.php');
    if(isset($_POST['login'])){
        $account = $_POST['username'];
        $pass = md5($_POST['password']);
        $sql = "SELECT * FROM tbl_admin WHERE username='".$account."' AND password='".$pass."' LIMIT 1";
        $row = mysqli_query($connect, $sql);
        $count = mysqli_num_rows($row);
        if($count>0){
            $_SESSION['login'] = $account;
            header("Location:index.php");
        } else {
            echo '<script>alert("Tài khoản hoặc Mật khẩu không đúng, vui lòng nhập lại.")</script>';
            header("Location:login.php");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập Admin</title>
    <style>
        body {
            background: #f2f2f2;
        }
        .table-login {
            width: 100%;
            text-align: center;
            border-collapse: collapse;
        }
        .table-login tr td {
            padding: 5px;
        }
        .wrapper-login {
            width: 25%;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper-login">
        <form action="" autocomplete="off" method="POST">
            <table class="table-login" border="1">
                <tr>
                    <td colspan="2"><h3>Đăng nhập Admin</h3></td>
                </tr>
                <tr>
                    <td>Tài khoản</td>
                    <td><input type="text" name="username"></td>
                </tr>
                <tr>
                    <td>Mật khẩu</td>
                    <td><input type="password" name="password"></td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" name="login" value="Đăng nhập"></td>
                </tr>
            </table>
        </form>
    </div>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</body>
</html>