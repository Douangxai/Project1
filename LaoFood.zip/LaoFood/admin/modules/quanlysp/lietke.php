<?php
if(isset($_GET['page'])){
    $pages = $_GET['page'];
} else {
    $pages = 1;
} if($pages == '' || $pages == 1){
    $begin = 0;
} else {
    $begin = ($pages*5)-5;
}
    $sql_page = mysqli_query($connect, "SELECT * FROM tbl_sanpham, tbl_danhmuc WHERE tbl_sanpham.id_danhmuc=tbl_danhmuc.id_danhmuc");
    $row_count = mysqli_num_rows($sql_page);
    $page = ceil($row_count/5);

    $sql_lietke_sp = "SELECT * FROM tbl_sanpham, tbl_danhmuc 
                        WHERE tbl_sanpham.id_danhmuc=tbl_danhmuc.id_danhmuc ORDER BY id_sanpham DESC LIMIT $begin,5";
    $query_lietke_sp = mysqli_query($connect, $sql_lietke_sp);
?>
<style>
    .lietke h2 {
        text-align: center;
    }
    .lietke table {
        border-collapse: collapse;
        margin: auto;
        width: 80%;
        text-align: center;
    }
    .lietke table th {
        padding: 1rem;
    }
    ul.pages {
        text-align: right;
        width: 90%;
        padding: 1.5rem;
    }
    .active {
        background-color: blue;
        border-radius: 30%
    }
    .active a {
        color: #fff;
    }
</style>
<div class="lietke">
<h2>Liệt kê sản phẩm</h2>
<ul class="list-inline list-unstyled pages">
    <li class="prev" style="display:<?php if($page<=1) echo 'none'; else echo ''; ?>">
        <a href="index.php?action=quanlysp&query=add&page=<?php if($pages>1) echo $pages-1; else echo 1; ?>">
            <i class="fa fa-angle-left"></i>
        </a>
    </li>
    <?php for($i=1; $i<=$page; $i++){ ?>
    <li class="<?php if($pages==$i) echo 'active' ?>" style="display:<?php if($page<=1) echo 'none'; else echo ''; ?>">
    <a href="index.php?action=quanlysp&query=add&page=<?php echo $i ?>"><?php echo $i ?></a>
    </li>
    <?php } ?>
    <li class="next" style="display:<?php if($page<=1) echo 'none'; else echo ''; ?>">
        <a href="index.php?action=quanlysp&query=add&page=<?php if($pages==$page) echo $pages; else echo $pages+1; ?>">
            <i class="fa fa-angle-right"></i>
        </a>
    </li>
</ul>
<table border="1">
  <form method="POST" action="modules/quanlysp/settle.php">
    <tr>
        <th>ID</td>
        <th>Tên sản phẩm</th>
        <th>Hình ảnh</th>
        <th>Giá sp</th>
        <th>Danh mục</th>
        <th>Tóm tắt</th>
        <th>Trạng thái</th>
        <th>Loại thức phẩm</th>
        <th>Quản lý</th>
    </tr>
    <?php
        $i = 0;
        while ($row = mysqli_fetch_array($query_lietke_sp)) {
            $i++;
        
    ?>
    <tr>
        <td><?php echo $i ?></td>
        <td><?php echo $row['tensanpham'] ?></td>
        <td><img src="../assets/images/menu/<?php echo $row['hinhanh']?> "width="150px"></td>
        <td><?php echo $row['giasp'] ?></td>
        <td><?php echo $row['tendanhmuc'] ?></td>
        <td><?php echo $row['tomtat'] ?></td>
        <td><?php if($row['tinhtrang']==1){
                echo 'Kịch hoạt';
            } else {
                echo 'Ẩn';
            } ?>
        </td>
        <td><?php if($row['category']==2){
                echo 'Đồ uống';
            } else if($row['category']==3){
                echo 'Món ăn trạng miệng';
            } else {
                echo 'Món chính';
            } ?></td>
        <td>
            <a href="modules/quanlysp/settle.php?idsanpham=<?php echo $row['id_sanpham'] ?>">Xóa</a> | 
            <a href="?action=quanlysp&query=fix&idsanpham=<?php echo $row['id_sanpham'] ?>">Sửa</a>
        </td>
    </tr>
    <?php
        }
    ?>
  </form>
</table>
<ul class="list-inline list-unstyled pages">
    <li class="prev" style="display:<?php if($page<=1) echo 'none'; else echo ''; ?>">
        <a href="index.php?action=quanlysp&query=add&page=<?php if($pages>1) echo $pages-1; else echo 1; ?>">
            <i class="fa fa-angle-left"></i>
        </a>
    </li>
    <?php for($i=1; $i<=$page; $i++){ ?>
    <li class="<?php if($pages==$i) echo 'active' ?>" style="display:<?php if($page<=1) echo 'none'; else echo ''; ?>">
    <a href="index.php?action=quanlysp&query=add&page=<?php echo $i ?>"><?php echo $i ?></a>
    </li>
    <?php } ?>
    <li class="next" style="display:<?php if($page<=1) echo 'none'; else echo ''; ?>">
        <a href="index.php?action=quanlysp&query=add&page=<?php if($pages==$page) echo $pages; else echo $pages+1; ?>">
            <i class="fa fa-angle-right"></i>
        </a>
    </li>
</ul>
</div>
