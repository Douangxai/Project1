<?php
    include('../../config/config.php');

    $tensanpham = $_POST['tensanpham'];
    $giasp = $_POST['giasp'];
    $tomtat = $_POST['tomtat'];
    $noidung = $_POST['noidung'];
    $tinhtrang = $_POST['tinhtrang'];
    $danhmuc = $_POST['danhmuc'];
    $cate = $_POST['cate'];
    // xử lý hình ảnh
    $hinhanh = $_FILES['hinhanh']['name'];
    $hinhanh_tmp = $_FILES['hinhanh']['tmp_name'];
    //$hinhanh = time().'_'.$hinhanh;
    if(isset($_POST['themsanpham'])) {
        // Thêm
        $sql_them = "INSERT INTO tbl_sanpham(tensanpham, giasp, hinhanh, tomtat, noidung, tinhtrang, id_danhmuc, category)
                     VALUE('".$tensanpham."','".$giasp."','".$hinhanh."','".$tomtat."','".$noidung."','".$tinhtrang."','".$danhmuc."','".$cate."')";
        mysqli_query($connect, $sql_them);
        move_uploaded_file($hinhanh_tmp, '../../../assets/images/menu/'.$hinhanh);
        header('Location:../../index.php?action=quanlysp&query=add');
    } else if (isset($_POST['suasanpham'])) {
        // Sửa
        if($hinhanh != ''){
            $sql_update = "UPDATE tbl_sanpham SET tensanpham='".$tensanpham."',giasp='".$giasp."',hinhanh='".$hinhanh."',tomtat='".$tomtat.
            "',noidung='".$noidung."',tinhtrang='".$tinhtrang."',id_danhmuc='".$danhmuc."',category='".$cate."' WHERE id_sanpham='$_GET[idsanpham]'";
        } else {
            $sql_update = "UPDATE tbl_sanpham SET tensanpham='".$tensanpham."',giasp='".$giasp."',tomtat='".$tomtat."',noidung='".$noidung.
            "',tinhtrang='".$tinhtrang."',id_danhmuc='".$danhmuc."',category='".$cate."' WHERE id_sanpham='$_GET[idsanpham]'";
        }
        
        mysqli_query($connect, $sql_update);
        move_uploaded_file($hinhanh_tmp, '../../../assets/images/menu/'.$hinhanh);
        header('Location:../../index.php?action=quanlysp&query=add');
    } else {
        $id=$_GET['idsanpham'];
        $sql = "SELECT * FROM tbl_sanpham WHERE id_sanpham = '$id' LIMIT 1";
        $query = mysqli_query($connect, $sql);
        while($row = mysqli_fetch_array($query)){
            unlink('../../../assets/images/menu/'.$row['hinhanh']);
        }
        $sql_xoa = "DELETE FROM tbl_sanpham WHERE id_sanpham='".$id."'";
        mysqli_query($connect, $sql_xoa);
        header('Location:../../index.php?action=quanlysp&query=add');
    }
?>