<h2 style="text-align: center;">Liệt kê đơn hàng</h2>
<?php
	$sql_lietke_dh = "SELECT * FROM tbl_order, account WHERE tbl_order.id_account=account.id_account ORDER BY date DESC";
	$query_lietke_dh = mysqli_query($connect,$sql_lietke_dh);
?>
<table style="width:100%" border="1" style="border-collapse: collapse;">
  <tr>
  	<th>Id</th>
    <th>Mã đơn hàng</th>
    <th>Tên khách hàng</th>
    <th>Email</th>
    <th>Số điện thoại</th>
    \<th>Địa chỉ</th>
    <th>Tình trạng</th>
    <th>Ngày đặt</th>
  	<th>Quản lý</th>  
  </tr>
  <?php
  $i = 0;
  while($row = mysqli_fetch_array($query_lietke_dh)){
  	$i++;
  ?>
  <tr>
  	<td><?php echo $i ?></td>
    <td><?php echo $row['code_order'] ?></td>
    <td><?php echo $row['username'] ?></td>
    <td><?php echo $row['email'] ?></td>
    <td><?php echo $row['phone'] ?></td>
    <td><?php echo $row['address'] ?></td>
    <td>
    	<?php if($row['order_status']==1){
    		echo '<a href="modules/quanlydonhang/xuly.php?tt=1&code='.$row['code_order'].'">Đơn hàng mới</a>';
    	}else{
    		echo '<a href="modules/quanlydonhang/xuly.php?tt=0&code='.$row['code_order'].'">Đã xem</a>';
    	}
    	?>
    </td>
    <td><?php echo $row['date'] ?></td>
   	<td>
   		<a href="index.php?action=donhang&query=xemdonhang&code=<?php echo $row['code_order'] ?>">Xem đơn hàng</a> 
   	</td>
   
  </tr>
  <?php
  } 
  ?>
 
</table>