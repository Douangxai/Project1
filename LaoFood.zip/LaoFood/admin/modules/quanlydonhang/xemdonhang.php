
<?php
	$code = $_GET['code'];
	$sql_lietke_dh = "SELECT * FROM tbl_cart,tbl_sanpham WHERE tbl_cart.id_sanpham=tbl_sanpham.id_sanpham AND tbl_cart.code_order='".$code."' ORDER BY tbl_cart.id_cart DESC";
	$query_lietke_dh = mysqli_query($connect,$sql_lietke_dh);
?>
<style>
  .lietke h2 {
    text-align: center;
  }
  .lietke table {
    border-collapse: collapse;
    margin: auto;
    width: 80%;
    text-align: center;
  }
  .lietke table th {
    padding: 1rem;
  }
  .lietke table {
    margin: auto;
  }
  ul.pages {
    text-align: right;
    width: 90%;
    padding: 1.5rem;
  }
</style>
<div class="lietke">
<h2>Xem đơn hàng</h2>
<table border="1">
  <tr>
  	<th>Id</th>
    <th>Mã đơn hàng</th>
    <th>Hình ảnh</th>
    <th>Tên sản phẩm</th>
    <th>Số lượng</th>
    <th>Đơn giá</th>
    <th>Thành tiền</th>
  </tr>
  <?php
  $i = 0;
  $tongtien = 0;
  while($row = mysqli_fetch_array($query_lietke_dh)){
  	$i++;
  	$thanhtien = $row['giasp']*$row['soluong'];
  	$tongtien += $thanhtien ;
  ?>
  <tr>
  	<td><?php echo $i ?></td>
    <td><?php echo $row['code_order'] ?></td>
    <td><img src="../assets/images/menu/<?php echo $row['hinhanh']?> "width="150px"></td>
    <td><?php echo $row['tensanpham'] ?></td>
    <td><?php echo $row['soluong'] ?></td>
    <td><?php echo number_format($row['giasp'],0,',','.').' VND' ?></td>
    <td><?php echo number_format($thanhtien,0,',','.').' VND' ?></td>
   	
  </tr>
  <?php
  } 
  ?>
  <tr>
  	<td colspan="7">
   		<h4>Tổng tiền : <?php echo number_format($tongtien,0,',','.').' VND' ?></h4>
   	</td>
   
  </tr>
 
</table>
</div>