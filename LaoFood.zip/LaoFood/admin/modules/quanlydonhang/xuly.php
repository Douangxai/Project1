<?php
	
    // require('../../../carbon/autoload.php');
	include('../../config/config.php');
	// use Carbon\Carbon;
    // use Carbon\CarbonInterval;
    // $now = Carbon::now('Asia/Ho_Chi_Minh')->toDateString();
	if(isset($_GET['code'])){
		$code_order = $_GET['code'];
        $trangthai = $_GET['tt'];
        if ($trangthai == 1) {
            $trangthai = 0;
        }else {
            $trangthai = 1;
        }
		$sql_update ="UPDATE tbl_order SET order_status= $trangthai WHERE code_order='".$code_order."'";
		$query = mysqli_query($connect,$sql_update);

		//thong ke doanh thu
       
    

		header('Location:../../index.php?action=quanlydonhang&query=lietke');
	} 
?>