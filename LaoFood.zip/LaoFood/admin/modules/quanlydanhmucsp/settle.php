<?php
    include('../../config/config.php');

    $tenloaisp = $_POST['tendanhmuc'];
    $thutu = $_POST['thutu'];
    if(isset($_POST['themdanhmuc'])) {
        $sql_them = "INSERT INTO tbl_danhmuc (tendanhmuc, thutu) VALUE('".$tenloaisp."','".$thutu."')";
        mysqli_query($connect, $sql_them);
        header('Location:../../index.php?action=quanlydanmucsanpham&query=add');
    } else if (isset($_POST['suadanhmuc'])) {
        $sql_update = "UPDATE tbl_danhmuc SET tendanhmuc='".$tenloaisp."',thutu='".$thutu."' WHERE id_danhmuc='$_GET[iddanhmuc]'";
        mysqli_query($connect, $sql_update);
        header('Location:../../index.php?action=quanlydanmucsanpham&query=add');
    } else {
        $id=$_GET['iddanhmuc'];
        $sql_xoa = "DELETE FROM tbl_danhmuc WHERE id_danhmuc='".$id."'";
        mysqli_query($connect, $sql_xoa);
        header('Location:../../index.php?action=quanlydanmucsanpham&query=add');
    }
?>