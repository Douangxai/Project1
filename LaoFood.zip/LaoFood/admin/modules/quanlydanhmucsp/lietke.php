<?php
    $sql_lietke_danhmucsp = "SELECT * FROM tbl_danhmuc ORDER BY thutu ASC";
    $query_lietke_danhmucsp = mysqli_query($connect, $sql_lietke_danhmucsp);
?>
<h2>Liệt kê danh mục sản phẩm</h2>
<table border="1" width="50%" style="border-collapse: collapse">
  <form method="POST" action="modules/quanlydanhmucsp/settle.php">
    <tr>
        <th>STT</td>
        <th>Tên danh mục</th>
        <th>Quản lý</th>
    </tr>
    <?php
        $i = 0;
        while ($row = mysqli_fetch_array($query_lietke_danhmucsp)) {
            $i++;
        
    ?>
    <tr>
        <td><?php echo $i ?></td>
        <td><?php echo $row['tendanhmuc'] ?></td>
        <td>
            <a href="modules/quanlydanhmucsp/settle.php?iddanhmuc=<?php echo $row['id_danhmuc'] ?>">Xóa</a> | 
            <a href="?action=quanlydanhmucsanpham&query=fix&iddanhmuc=<?php echo $row['id_danhmuc'] ?>">Sửa</a>
        </td>
    </tr>
    <?php
        }
    ?>
  </form>
</table>
