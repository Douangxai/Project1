<p>Thêm danh mục sản phẩm</p>
<table border="1" width="50%" style="border-collapse: collapse">
  <form method="POST" action="modules/quanlydanhmucsp/settle.php">
    <tr>
        <td>Tên danh mục</td>
        <td><input type="text" name="tendanhmuc"></td>
    </tr>
    <tr>
        <td>Thứ tự</td>
        <td><input type="text" name="thutu"></td>
    </tr>
    <tr colspan="2">
        <td><input type="submit" name="themdanhmuc" value="Thêm danh mục sản phẩm"></td>
    </tr>
  </form>
</table>
