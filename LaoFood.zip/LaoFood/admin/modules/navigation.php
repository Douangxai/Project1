
<ul class="nav navbar-nav">
    <li class="dropdown mega-menu"><a href="index.php?action=quanlydanmucsanpham&query=add">Quản lý danh mục sản phẩm</a></li>
    <li class="dropdown mega-menu"><a href="index.php?action=quanlysp&query=add&page=1">Quản lý phẩm</a></li>
    <li class="dropdown mega-menu"><a href="index.php?action=quanlybaiviet&query=add">Quản lý bài viết</a></li>
    <li class="dropdown mega-menu"><a href="index.php?action=quanlydonhang&query=lietke">Quản lý đơn hàng</a></li>
</ul>