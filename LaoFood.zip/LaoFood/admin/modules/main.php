<div class="clear"></div>
<div class="main">
    <?php
        if(isset($_GET['action']) && $_GET['query']) {
            $tam = $_GET['action'];
            $query = $_GET['query'];
        } else {
            $tam = '';
            $query = '';
        }
        if($tam == 'quanlydanmucsanpham' && $query=='add') {
            include("modules/quanlydanhmucsp/add.php");
            include("modules/quanlydanhmucsp/lietke.php");
        } else if($tam == 'quanlydanhmucsanpham' && $query=='fix'){
            include("modules/quanlydanhmucsp/fix.php");
        } else if($tam == 'quanlysp' && $query=='add') {
            include("modules/quanlysp/add.php");
            include("modules/quanlysp/lietke.php");
        } else if($tam == 'quanlysp' && $query=='fix'){
            include("modules/quanlysp/fix.php");
        } else if($tam == 'quanlybaiviet' && $query=='add') {
            include("modules/quanlybaiviet/add.php");
            include("modules/quanlybaiviet/lietke.php");
        } else if($tam == 'quanlybaiviet' && $query=='fix'){
            include("modules/quanlybaiviet/fix.php");
        } else if($tam == 'quanlydonhang' && $query=='lietke') {
            include("modules/quanlydonhang/lietke.php");
        } else if($tam == 'quanlydonhang' && $query=='lietke') {
            include("modules/quanlydonhang/lietke.php");
        }elseif($tam=='donhang' && $query=='xemdonhang'){
            include("modules/quanlydonhang/xemdonhang.php");
        } else {
            include("modules/dashboard.php");
        }
        
    ?>
</div>
