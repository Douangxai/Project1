<?php
    if(isset($_GET['logout'])&& $_GET['logout']==1) {
        unset($_SESSION['login']);
        header('Location:login.php');
    }
?>

<div class="header">
    <p>
        <a href="index.php?logout=1">
            Đăng xuất : <?php if(isset($_SESSION['login'])){
            echo $_SESSION['login'];
            } ?>
        </a>
        </p>
</div>
