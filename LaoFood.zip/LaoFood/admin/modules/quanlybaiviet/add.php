<p>Thêm bài viết</p>
<table border="1" width="100%" style="border-collapse: collapse">
  <form method="POST" action="modules/quanlybaiviet/settle.php" enctype="multipart/form-data">
    <tr>
        <td>Tên bài viết</td>
        <td><input type="text" name="tenbaiviet"></td>
    </tr>
    <tr>
        <td>Hình ảnh</td>
        <td><input type="file" name="hinhanh"></td>
    </tr>
    <tr>
        <td>Tóm tắt</td>
        <td><textarea name="tomtat"></textarea></td>
    </tr>
    <tr>
        <td>Nội dung</td>
        <td><textarea name="noidung"></textarea></td>
    </tr>
    <tr>
        <td>Tình trạng</td>
        <td>
          <select name="tinhtrang">
            <option value="1">Kích hoạt</option>
            <option value="0">Ẩn</option>
          </select>
        </td>
    </tr>
    <tr>
        <td colspan="2"><input type="submit" name="thembaiviet" value="Thêm bài viết"></td>
    </tr>
  </form>
</table>
