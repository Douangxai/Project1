<?php
    $sql_lietke_bv = "SELECT * FROM blog ORDER BY date DESC";
    $query_lietke_bv = mysqli_query($connect, $sql_lietke_bv);
?>
<style>
    .lietke h2 {
        text-align: center;
    }
    .lietke table {
        border-collapse: collapse;
        margin: auto;
        width: 80%;
        text-align: center;
    }
    .lietke table th {
        padding: 1rem;
    }
</style>
<div class="lietke">
<h2>Liệt kê bài viết</h2>
<table border="1">
  <form method="POST" action="modules/quanlybaiviet/settle.php">
    <tr>
        <th>ID</td>
        <th>Tên sản phẩm</th>
        <th>Hình ảnh</th>
        <th>Tóm tắt</th>
        <th>Trạng thái</th>
        <th>Ngày hiển ra</th>
        <th>Quản lý</th>
    </tr>
    <?php
        $i = 0;
        while ($row = mysqli_fetch_array($query_lietke_bv)) {
            $i++;
        
    ?>
    <tr>
        <td><?php echo $i ?></td>
        <td><?php echo $row['tenbaiviet'] ?></td>
        <td><img src="../assets/images/blog-post/<?php echo $row['hinhanh']?> "width="150px"></td>
        <td><?php echo $row['tomtat'] ?></td>
        <td><?php if($row['tinhtrang']==1){
                echo 'Kịch hoạt';
            } else {
                echo 'Ẩn';
            } ?>
        </td>
        <td> <?php echo $row['date'] ?></td>
        <td>
            <a href="modules/quanlybaiviet/settle.php?idbaiviet=<?php echo $row['id'] ?>">Xóa</a> | 
            <a href="?action=quanlybaiviet&query=fix&idbaiviet=<?php echo $row['id'] ?>">Sửa</a>
        </td>
    </tr>
    <?php
        }
    ?>
  </form>
</table>
</div>
