<?php
    include('../../config/config.php');

    $tenbaiviet = $_POST['tenbaiviet'];
    $tomtat = $_POST['tomtat'];
    $noidung = $_POST['noidung'];
    $tinhtrang = $_POST['tinhtrang'];
    // xử lý hình ảnh
    $hinhanh = $_FILES['hinhanh']['name'];
    $hinhanh_tmp = $_FILES['hinhanh']['tmp_name'];
    //$hinhanh = time().'_'.$hinhanh;
    if(isset($_POST['thembaiviet'])) {
        // Thêm
        $sql_them = "INSERT INTO blog(tenbaiviet, hinhanh, tomtat, noidung, tinhtrang)
                     VALUE('".$tenbaiviet."','".$hinhanh."','".$tomtat."','".$noidung."','".$tinhtrang."')";
        mysqli_query($connect, $sql_them);
        move_uploaded_file($hinhanh_tmp, '../../../assets/images/blog-post/'.$hinhanh);
        header('Location:../../index.php?action=quanlybaiviet&query=add');
     } 
    else if (isset($_POST['suabaiviet'])) {
        // Sửa
        if($hinhanh != ''){
            $sql_update = "UPDATE blog SET tenbaiviet='".$tenbaiviet."',hinhanh='".$hinhanh."',tomtat='".$tomtat.
                            "',noidung='".$noidung."',tinhtrang='".$tinhtrang."' WHERE id='$_GET[idbaiviet]'";
        } else {
            $sql_update = "UPDATE blog SET tenbaiviet='".$tenbaiviet."',tomtat='".$tomtat. "',noidung='".$noidung.
                            "',tinhtrang='".$tinhtrang."' WHERE id='$_GET[idbaiviet]'";
        }
        
        mysqli_query($connect, $sql_update);
        move_uploaded_file($hinhanh_tmp, '../../../assets/images/blog-post/'.$hinhanh);
        header('Location:../../index.php?action=quanlybaiviet&query=add');
    } else {
        $id=$_GET['idbaiviet'];
        $sql = "SELECT * FROM blog WHERE id = '$id' LIMIT 1";
        $query = mysqli_query($connect, $sql);
        while($row = mysqli_fetch_array($query)){
            unlink('../../../assets/images/blog-post/'.$row['hinhanh']);
        }
        $sql_xoa = "DELETE FROM blog WHERE id='".$id."'";
        mysqli_query($connect, $sql_xoa);
        header('Location:../../index.php?action=quanlybaiviet&query=add');
    }
?>