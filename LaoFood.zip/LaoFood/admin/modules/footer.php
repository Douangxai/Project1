<!-- ============================================== BRANDS CAROUSEL ============================================== -->
<div id="brands-carousel" class="logo-slider">
    <div class="logo-slider-inner">
        <div id="brand-slider" class="owl-carousel brand-slider custom-carousel owl-theme">
            <div class="item m-t-15"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand1.png"
                        src="assets/images/blank.gif" alt=""> </a>
            </div>
            <!--/.item-->

            <div class="item m-t-10"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand2.png"
                        src="assets/images/blank.gif" alt=""> </a>
            </div>
            <!--/.item-->

            <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand3.png"
                        src="assets/images/blank.gif" alt=""> </a> </div>
            <!--/.item-->

            <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand4.png"
                        src="assets/images/blank.gif" alt=""> </a> </div>
            <!--/.item-->

            <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand5.png"
                        src="assets/images/blank.gif" alt=""> </a> </div>
            <!--/.item-->

            <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand6.png"
                        src="assets/images/blank.gif" alt=""> </a> </div>
            <!--/.item-->

            <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand2.png"
                        src="assets/images/blank.gif" alt=""> </a> </div>
            <!--/.item-->

            <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand4.png"
                        src="assets/images/blank.gif" alt=""> </a> </div>
            <!--/.item-->

            <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand1.png"
                        src="assets/images/blank.gif" alt=""> </a> </div>
            <!--/.item-->

            <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand5.png"
                        src="assets/images/blank.gif" alt=""> </a> </div>
            <!--/.item-->
        </div>
        <!-- /.owl-carousel #logo-slider -->
    </div>
    <!-- /.logo-slider-inner -->

</div>
<!-- /.logo-slider -->
<!-- ============================================== BRANDS CAROUSEL : END ============================================== -->

<!-- ============================================== INFO BOXES : END ============================================== -->

<footer id="footer" class="footer color-bg">
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="address-block">

                        <!-- /.module-heading -->

                        <div class="module-body">
                            <div class="toggle-footer" style="">
                                <div class="media">
                                    <div class="pull-left"> <span class="icon fa-stack fa-lg"> 
                                        <i class="fa fa-map-marker fa-stack-1x fa-inverse"></i> </span> </div>
                                </div>
                                <div class="media-body">
                                <br>
                                    <p>470 Đ. Trần Đại Nghĩa, Khu đô thị, Ngũ Hành Sơn, Đà Nẵng 550000, Vietnam</p>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- /.module-body -->
                </div>
                <!-- /.col -->
                <div class="module-body">
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="toggle-footer" style="">
                        <div class="media">
                            <div class="pull-left"> <span class="icon fa-stack fa-lg"> 
                                <i class="fa fa-mobile fa-stack-1x fa-inverse"></i> </span> </div>
                        </div>
                        <div class="media-body">
                                <br>
                            <p> + (888) 123-4567 </p>
                            <p> + (888) 456-7890 </p>
                        </div>
                    </div>
                </div></div>
                <!-- /.col -->
                <div class="module-body">
                <div class="col-xs-12 col-sm-6 col-md-4">
                    <div class="toggle-footer" style="">
                        <div class="media">
                            <div class="pull-left"> <span class="icon fa-stack fa-lg"> 
                                <i class="fa fa-envelope fa-stack-1x fa-inverse"></i> </span> </div>
                        </div>
                                <br>
                        <div class="media-body"> <span>laofood@gmail.com</span>
                        </div>
                    </div></div>
                    <!-- /.col -->

                </div>
            </div>
        </div>
    </div>
</footer>