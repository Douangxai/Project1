
         <!-- ============================================== BRANDS CAROUSEL ============================================== -->
         <div id="brands-carousel" class="logo-slider">
             <div class="logo-slider-inner">
                 <div id="brand-slider" class="owl-carousel brand-slider custom-carousel owl-theme">
                     <div class="item m-t-15"> <a href="#" class="image"> <img
                                 data-echo="assets/images/brands/brand1.png" src="assets/images/blank.gif" alt=""> </a>
                     </div>
                     <!--/.item-->

                     <div class="item m-t-10"> <a href="#" class="image"> <img
                                 data-echo="assets/images/brands/brand2.png" src="assets/images/blank.gif" alt=""> </a>
                     </div>
                     <!--/.item-->

                     <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand3.png"
                                 src="assets/images/blank.gif" alt=""> </a> </div>
                     <!--/.item-->

                     <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand4.png"
                                 src="assets/images/blank.gif" alt=""> </a> </div>
                     <!--/.item-->

                     <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand5.png"
                                 src="assets/images/blank.gif" alt=""> </a> </div>
                     <!--/.item-->

                     <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand6.png"
                                 src="assets/images/blank.gif" alt=""> </a> </div>
                     <!--/.item-->

                     <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand2.png"
                                 src="assets/images/blank.gif" alt=""> </a> </div>
                     <!--/.item-->

                     <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand4.png"
                                 src="assets/images/blank.gif" alt=""> </a> </div>
                     <!--/.item-->

                     <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand1.png"
                                 src="assets/images/blank.gif" alt=""> </a> </div>
                     <!--/.item-->

                     <div class="item"> <a href="#" class="image"> <img data-echo="assets/images/brands/brand5.png"
                                 src="assets/images/blank.gif" alt=""> </a> </div>
                     <!--/.item-->
                 </div>
                 <!-- /.owl-carousel #logo-slider -->
             </div>
             <!-- /.logo-slider-inner -->

         </div>
         <!-- /.logo-slider -->
         <!-- ============================================== BRANDS CAROUSEL : END ============================================== -->
 <!-- ============================================== INFO BOXES ============================================== -->
 <div class="row our-features-box">
     <div class="container">
         <ul>
             <li>
                 <div class="feature-box">
                     <div class="icon-truck"></div>
                     <div class="content-blocks">Chuyển hàng nhanh chóng</div>
                 </div>
             </li>
             <li>
                 <div class="feature-box">
                     <div class="icon-support"></div>
                     <div class="content-blocks">Gọi + (84) 0827 852 316</div>
                 </div>
             </li>
             <li>
                 <div class="feature-box">
                     <div class="icon-money"></div>
                     <div class="content-blocks">Giá cả hợp lý</div>
                 </div>
             </li>
             <li>
                 <div class="feature-box">
                     <div class="icon-return"></div>
                     <div class="content">Phục vụ tận tầm</div>
                 </div>
             </li>

         </ul>
     </div>
 </div>
 <!-- /.info-boxes -->
 <!-- ============================================== INFO BOXES : END ============================================== -->

<footer id="footer" class="footer color-bg">
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-4 col-md-5">
                    <div class="address-block">

                        <!-- /.module-heading -->

                        <div class="module-body">
                            <ul class="toggle-footer" style="">
                                <li class="media">
                                    <div class="pull-left"> <span class="icon fa-stack fa-lg"> <i
                                                class="fa fa-map-marker fa-stack-1x fa-inverse"></i> </span> </div>
                                    <div class="media-body">
                                        <p>470 Đ. Trần Đại Nghĩa, Khu đô thị, Ngũ Hành Sơn, Đà Nẵng 550000, Vietnam</p>
                                    </div>
                                </li>
                                <li class="media">
                                    <div class="pull-left"> <span class="icon fa-stack fa-lg"> <i
                                                class="fa fa-mobile fa-stack-1x fa-inverse"></i> </span> </div>
                                    <div class="media-body">
                                        <p> + (84) 0827 852 316 / + (856) 20 9575 5332</p>
                                    </div>
                                </li>
                                <li class="media">
                                    <div class="pull-left"> <span class="icon fa-stack fa-lg"> <i
                                                class="fa fa-envelope fa-stack-1x fa-inverse"></i> </span> </div>
                                    <div class="media-body"> <span><a href="#">laofood@gmail.com</a></span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- /.module-body -->
                </div>
                <!-- /.col -->

                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class="module-heading">
                        <h4 class="module-title">Dịch vụ khách hàng</h4>
                    </div>
                    <!-- /.module-heading -->

                    <div class="module-body">
                        <ul class='list-unstyled'>
                            <li class="first"><a href="#" title="Contact us">Tài khoản của tôi</a></li>
                            <li><a href="#" title="About us">Lịch sử đơn hàng</a></li>
                            <li><a href="#" title="faq">Câu hỏi thường gặp</a></li>
                            <li><a href="#" title="Popular Searches">Khuyến mãi</a></li>
                            <li class="last"><a href="index.php?quanly=checkout" title="Where is my order?">Hỗ trợ</a></li>
                        </ul>
                    </div>
                    <!-- /.module-body -->
                </div>
                <!-- /.col -->

                <div class="col-xs-12 col-sm-4 col-md-3">
                    <div class="module-heading">
                        <h4 class="module-title">tại sao chọn chúng tôi</h4>
                    </div>
                    <!-- /.module-heading -->

                    <div class="module-body">
                        <ul class='list-unstyled'>
                            <li class="first"><a href="#" title="About us">Hướng dẫn mua sắm</a></li>
                            <li><a href="index.php?quanly=blog&page=1" title="Blog">Tin tức</a></li>
                            <li><a href="#" title="Company">Cửa hàng</a></li>
                            <li class=" last"><a href="index.php?quanly=contact" title="Suppliers">Liên hệ chúng tôi</a></li>
                        </ul>
                    </div>
                    <!-- /.module-body -->
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-bar">
        <div class="container">
            <div class="col-xs-12 col-sm-4 no-padding social">
                <ul class="link">
                    <li class="fb pull-left"><a target="_blank" rel="nofollow" href="#" title="Facebook"></a></li>
                    <li class="tw pull-left"><a target="_blank" rel="nofollow" href="#" title="Twitter"></a></li>
                    <li class="googleplus pull-left"><a target="_blank" rel="nofollow" href="#" title="GooglePlus"></a>
                    </li>
                    <li class="rss pull-left"><a target="_blank" rel="nofollow" href="#" title="RSS"></a></li>
                    <li class="pintrest pull-left"><a target="_blank" rel="nofollow" href="#" title="PInterest"></a>
                    </li>
                    <li class="linkedin pull-left"><a target="_blank" rel="nofollow" href="#" title="Linkedin"></a></li>
                    <li class="youtube pull-left"><a target="_blank" rel="nofollow" href="#" title="Youtube"></a></li>
                </ul>
            </div>
            <div class="col-xs-12 col-sm-4 no-padding copyright"><a target="_blank"
                    href="https://www.templateshub.net">Templates Hub</a> </div>
            <div class="col-xs-12 col-sm-4 no-padding">
                <div class="clearfix payment-methods">
                    <ul>
                        <li><img src="assets/images/payments/1.png" alt=""></li>
                        <li><img src="assets/images/payments/2.png" alt=""></li>
                        <li><img src="assets/images/payments/3.png" alt=""></li>
                        <li><img src="assets/images/payments/4.png" alt=""></li>
                        <li><img src="assets/images/payments/5.png" alt=""></li>
                    </ul>
                </div>
                <!-- /.payment-methods -->
            </div>
        </div>
    </div>
</footer>