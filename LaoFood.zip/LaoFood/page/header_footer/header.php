<?php

$sql_danhmuc = "SELECT * FROM tbl_danhmuc ORDER BY thutu ASC";
$query_danhmuc = mysqli_query($connect, $sql_danhmuc);
$query_sanpham = mysqli_query($connect, $sql_danhmuc);

 if(isset($_GET['logout']) && $_GET['logout']==1) {
    unset($_SESSION['sign-in']);
 }
?>
<header class="header-style-1">

    <!-- ============================================== TOP MENU ============================================== -->
    <div class="top-bar animate-dropdown">
        <div class="container">
            <div class="header-top-inner">
                <div class="cnt-account">
                    <ul class="list-unstyled">
                        <li class="wishlist"><a href="index.php?quanly=wishlist"><span>Ưa thích</span></a></li>
                        <li class="header_cart hidden-xs"><a href="index.php?quanly=cart"><span>Giỏ hàng</span></a></li>
                        <li class="check"><a href="index.php?quanly=checkout"><span>Đơn hàng</span></a></li>
                        <?php
                            if(isset($_SESSION['sign-in'])){
                        ?>
                        <li class="login"><a href="index.php?logout=1"><span>Đăng xuất</span></a></li>
                        <?php
                            } else {
                        ?>
                        <li class="login"><a href="index.php?quanly=sign-in"><span>Đăng nhập</span></a></li>
                        <?php } ?>
                        
                    </ul>
                </div>
                <!-- /.cnt-account -->

                <div class="cnt-block">
                    <ul class="list-unstyled list-inline">
                        <li class="dropdown dropdown-small lang"> <a href="#" class="dropdown-toggle"
                                data-hover="dropdown" data-toggle="dropdown"><span class="value">Tiếng Việt</span><b
                                    class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="#">English</a></li>
                                <li><a href="#">Vietnamese</a></li>
                                <li><a href="#">ພາສາລາວ</a></li>
                            </ul>
                        </li>
                    </ul>
                    <!-- /.list-unstyled -->
                </div>
                <!-- /.cnt-cart -->
                <div class="clearfix"></div>
            </div>
            <!-- /.header-top-inner -->
        </div>
        <!-- /.container -->
    </div>
    <!-- /.header-top -->
    <!-- ============================================== TOP MENU : END ============================================== -->
    <div class="main-header">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-3 logo-holder">
                    <!-- ============================================================= LOGO ============================================================= -->
                    <div class="logo"> <a href="index.php"> <img src="assets/images/Lao Food.jpg" alt="logo"> </a> </div>
                    <!-- /.logo -->
                    <!-- ============================================================= LOGO : END ============================================================= -->
                </div>
                <!-- /.logo-holder -->

                <div class="col-lg-7 col-md-6 col-sm-8 col-xs-12 top-search-holder">
                    <!-- /.contact-row -->
                    <!-- ============================================================= SEARCH AREA ============================================================= -->
                    <style>
                    input.search-field:focus {
                        outline: none;
                    }
                    </style>
                    <div class="search-area">
                        <form action="index.php?quanly=search" method="POST">
                            <div class="control-group">
                                <ul class="categories-filter animate-dropdown">
                                    <li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown"
                                            href="#">Danh mục <b class="caret"></b></a>
                                        <ul class="dropdown-menu" role="menu">
                                            <?php if(mysqli_num_rows($query_danhmuc) > 0){
                                                while($item = mysqli_fetch_array($query_danhmuc)){
                                                //để lấy được kết quả truy vấn thì sử dụng phương thức mysqli_fetch_array 
                                            ?>
                                            <li role="presentation"><a role="menuitem" tabindex="-1"
                                                    href="index.php?quanly=menu&id=<?= $item['id_danhmuc'] ?>">- <?= $item['tendanhmuc'] ?></a>
                                            </li>
                                            <?php }} ?>
                                        </ul>
                                    </li>
                                </ul>
                                <input name="keyword" class="search-field" placeholder="Bạn tìm gì..." />
                                <button type="submit" name="search" class="search-button" style="border: none;"></button>
                            </div>
                        </form>
                    </div>
                    <!-- /.search-area -->
                    <!-- ============================================================= SEARCH AREA : END ============================================================= -->
                </div>
                <!-- /.top-search-holder -->

                <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12 animate-dropdown top-cart-row">
                    <!-- ============================================================= SHOPPING CART DROPDOWN ============================================================= -->

                    <div class="dropdown dropdown-cart"> <a href="#" class="dropdown-toggle lnk-cart"
                            data-toggle="dropdown">
                            <div class="items-cart-inner">
                                <div class="basket">
                                <?php
                                    $total=0;
                                    $i = 0;
                                    if(isset($_SESSION['cart'])){
                                        foreach($_SESSION['cart'] as $cart_item){
                                            $price = $cart_item['soluong']*$cart_item['giasp'];
                                            $total+=$price;
                                            $i++;}}
                                ?>
                                    <div class="basket-item-count"><span class="count"><?php echo $i; ?></span></div>
                                    <div class="total-price-basket"> <span class="lbl">Giỏ hàng</span> 
                                        <span class="value"><?php echo number_format($total,0,',','.').' VND'; ?></span> 
                                    </div>
                                </div>
                            </div>
                        </a>
                        <ul class="dropdown-menu">
                            <li>
        <form method="POST" action="index.php?quanly=checkout">
                        <?php
                                $total=0;
                                if(isset($_SESSION['cart'])){
                                    $i = 0;
                                    foreach($_SESSION['cart'] as $cart_item){
                                        $price = $cart_item['soluong']*$cart_item['giasp'];
                                        $total+=$price;
                                        $i++;
                            ?>
                                <div class="cart-item product-summary">
                                    <div class="row">
                                        <div class="col-xs-4">
                                            <div class="image"> <a href="index.php?quanly=cart">
                                                <img src="assets/images/menu/<?php echo $cart_item['hinhanh']; ?>" alt="">
                                            </a> </div>
                                        </div>
                                        <div class="col-xs-7">
                                            <h3 class="name">
                                                <a href="index.php?quanly=item&id=<?php echo $cart_item['id']; ?>">
                                                    <?php echo $cart_item['tensanpham']; ?>
                                                </a>
                                            </h3>
                                            <div class="price"><?php echo $cart_item['soluong']."x".$cart_item['giasp']; ?> VND</div>
                                        </div>
                                        <div class="col-xs-1 action"> <a href="page/main/settle.php?del=<?php echo $cart_item['id'] ?>"><i class="fa fa-trash"></i></a> </div>
                                    </div>
                                </div>
                                <!-- /.cart-item -->
                                <div class="clearfix"></div>
                                <hr>
                        <?php
				}}
			?>
                                <div class="clearfix cart-total">
                                    <div class="pull-right"> 
                                        <span class="text">Sub Total :</span>
                                        <span class='price'><?php echo number_format($total,0,',','.').' VND'; ?></span>
                                    </div>
                                    <div class="clearfix"></div>
                                    <button  type="submit"  name="checkout" class="btn btn-upper btn-primary btn-block m-t-20">
                                        Checkout
                                    </button>
                                </div>
                                <!-- /.cart-total-->

                            </li>
            </form>
                        </ul>
                        <!-- /.dropdown-menu-->
                    </div>
                    <!-- /.dropdown-cart -->

                    <!-- ============================================================= SHOPPING CART DROPDOWN : END============================================================= -->
                </div>
                <!-- /.top-cart-row -->
            </div>
            <!-- /.row -->

        </div>
        <!-- /.container -->

    </div>
    <!-- /.main-header -->

    <!-- ============================================== NAVBAR ============================================== -->
    <div class="header-nav animate-dropdown">
        <div class="container">
            <div class="yamm navbar navbar-default" role="navigation">
                <div class="navbar-header">
                    <button data-target="#mc-horizontal-menu-collapse" data-toggle="collapse"
                        class="navbar-toggle collapsed" type="button">
                        <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span
                            class="icon-bar"></span> <span class="icon-bar"></span> </button>
                </div>
                <div class="nav-bg-class">
                    <div class="navbar-collapse collapse" id="mc-horizontal-menu-collapse">
                        <div class="nav-outer">
                            <ul class="nav navbar-nav">
                                <li class="active dropdown"> <a href="index.php">Trang chủ</a> </li>
                                <li class="dropdown yamm mega-menu"> <a href="menu.php" data-hover="dropdown"
                                        class="dropdown-toggle" data-toggle="dropdown">Sản phẩm</a>

                                    <ul class="dropdown-menu container">

                                        <li>
                                            <div class="yamm-content ">
                                                <div class="row">

                                                    <div class="col-sm-6 col-md-6 col-menu">

                                                        <ul class="links">
                                            <?php if(mysqli_num_rows($query_sanpham) > 0){
                                                while($item = mysqli_fetch_array($query_sanpham)){
                                                //để lấy được kết quả truy vấn thì sử dụng phương thức mysqli_fetch_array 
                                            ?>
                                                            <li><a href="index.php?quanly=menu&id=<?= $item['id_danhmuc'] ?>&page=1"> <?= $item['tendanhmuc'] ?></a></li>
                                                            <?php }} ?>

                                                        </ul>
                                                    </div>

                                                </div>
                                            </div>
                                        </li>

                                    </ul>
                                </li>
                                <li class="dropdown mega-menu">
                                    <a href="index.php?quanly=blog&page=1">Tin Tức</a>

                                </li>
                                <li class="dropdown mega-menu">
                                    <a href="index.php?quanly=contact">Liên hệ</a>

                                </li>
                               

                            </ul>
                            <!-- /.navbar-nav -->
                            <div class="clearfix"></div>
                        </div>
                        <!-- /.nav-outer -->
                    </div>
                    <!-- /.navbar-collapse -->

                </div>
                <!-- /.nav-bg-class -->
            </div>
            <!-- /.navbar-default -->
        </div>
        <!-- /.container-class -->

    </div>
    <!-- /.header-nav -->
    <!-- ============================================== NAVBAR : END ============================================== -->

</header>