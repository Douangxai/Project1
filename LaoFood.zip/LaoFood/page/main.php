<?php
    $sql_danhmuc = "SELECT * FROM tbl_danhmuc ORDER BY thutu ASC";
    $query_danhmuc = mysqli_query($connect, $sql_danhmuc);
?>

<div id="main">
            <div class="main-content">
                <?php
                    if(isset($_GET['quanly'])) {
                        $tam = $_GET['quanly'];
                    } else {
                        $tam = '';
                    }
                    if($tam == 'menu') {
                        include("main/menu.php");
                    } else if($tam == 'blog') {
                        include("main/blog.php");
                    } else if($tam == 'news') {
                        include("main/news.php");
                    } else if($tam == 'contact') {
                        include("main/contact.php");
                    } else if($tam == 'cart') {
                        include("main/cart.php");
                    } else if($tam == 'sign-in') {
                        include("main/sign-in.php");
                    } else if($tam == 'search') {
                        include("main/search.php");
                    } else if($tam == 'checkout') {
                        include("main/checkout.php");
                    } else if($tam == 'wishlist') {
                        include("main/wishlist.php");
                    }else if($tam == 'item') {
                        include("main/item.php");
                    } else {
                        include("main/index.php");
                    }
                ?>
            </div> 
        </div>