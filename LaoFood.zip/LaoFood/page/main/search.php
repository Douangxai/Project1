
<div class="breadcrumb">
  <div class="container">
    <div class="breadcrumb-inner">
      <ul class="list-inline list-unstyled">
        <li><a href="#">Home</a></li>
        <li class='active'>Menu</li>
      </ul>
    </div>
    <!-- /.breadcrumb-inner --> 
  </div>
  <!-- /.container --> 
</div>
<!-- /.breadcrumb -->
<div class="body-content outer-top-xs">
  <div class='container'>
    <div class='row'>
      <div class="col-xs-12 col-sm-12 col-md-12"> 
        <!-- ========================================== SECTION – HERO ========================================= -->

        <div class="clearfix filters-container m-t-10">
          <div class="row">
            <div class="col col-sm-6 col-md-3 col-lg-3 col-xs-6">
              <div class="filter-tabs">
                <ul id="filter-tabs" class="nav nav-tabs nav-tab-box nav-tab-fa-icon">
                  <li class="active"> <a data-toggle="tab" href="#grid-container"><i class="icon fa fa-th-large"></i>Grid</a> </li>
                  <li><a data-toggle="tab" href="#list-container"><i class="icon fa fa-bars"></i>List</a></li>
                </ul>
              </div>
              <!-- /.filter-tabs --> 
            </div>
            <!-- /.col -->

        </div>
        <div class="search-result-container ">
          <div id="myTabContent" class="tab-content category-list">
            <div class="tab-pane active " id="grid-container">
              <div class="category-product">
                <div class="row">
                <?php
                  if(isset($_POST['search'])){
                      $keyword = $_POST['keyword'];
                  } else {
                      $keyword = '';
                  }
                            // $qql_pro là câu truy vấn cơ sở dữ liệu
                  $sql_item = "SELECT * FROM tbl_sanpham WHERE tensanpham LIKE '%" .$keyword. "%'";
                  $query_item = mysqli_query($connect, $sql_item); //phương thức này sẽ chạy câu truy vấn
                  if(mysqli_num_rows($query_item) > 0){
                  while($item = mysqli_fetch_array($query_item)){
                    $sql_star = "SELECT ROUND(AVG(rating), 1) as star FROM tbl_review WHERE id_product=" . $item['id_sanpham'];
                    $query_star = mysqli_query($connect, $sql_star);
                    $result_star = mysqli_fetch_array($query_star);
                    $star = $result_star['star'];
                  //để lấy được kết quả truy vấn thì sử dụng phương thức mysqli_fetch_array 
                ?>
                <form action="page/main/settle.php?idsanpham=<?php echo $item['id_sanpham'] ?>" method="POST">
                  <div class="col-sm-6 col-md-4 col-lg-3">
                  <div class="item">
                    <div class="products">
                      <div class="product">
                        <div class="product-image">
                          <div class="image"> 
                          <a href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>">
                             <img src="assets/images/menu/<?php echo $item['hinhanh']?>"> 
                              <img src="assets/images/menu/<?php echo $item['hinhanh']?>" class="hover-image">
                          </a> 
                       </div>
                          <!-- /.image -->

                        </div>
                        <!-- /.product-image -->
                        
                        <div class="product-info text-left">
                        <input type="hidden" value="1" name="quantity">
                          <h3 class="name"><a href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>"><?php echo $item['tensanpham'] ?></a></h3>
                          <div class='rating-stars'>
                              <ul id='stars'>
                                  <?php 
                                      for($j=1; $j<=5; $j++){
                                  ?>
                                  <li class='star <?php if($star >= $j) echo 'hover'; ?>' data-value='<?php echo $j ?>' data-product_id="<?php echo $item['id_sanpham'] ?>">
                                      <i class='fa fa-star fa-fw'></i>
                                  </li>
                                  <?php 
                                      }
                                  ?>
                              </ul>
                          </div>
                          <div class="description"></div>
                          <div class="product-price"> <span class="price"><?php echo number_format($item['giasp'],0,',','.').' VND' ?></span></div>
                          <!-- /.product-price --> 
                          
                        </div>
                        <!-- /.product-info -->
                        <div class="cart clearfix animate-effect">
                          <div class="action">
                            <ul class="list-unstyled">
                            <li class="add-cart-button btn-group">
                                <button data-toggle="tooltip" class="btn btn-primary icon" type="submit" name="addtocart" title="ThêmGiỏHàng"> 
                                    <i class="fa fa-shopping-cart"></i> </button>
                                <button class="btn btn-primary cart-btn"
                                    type="button">Add to cart</button>
                            </li>
                            <li class="add-cart-button btn-group"> 
                                <button data-toggle="tooltip" class="btn btn-primary icon" type="submit" name="addwishlist" title="Ưa thích"> 
                                    <i class="icon fa fa-heart"></i>
                                </button> </li>
                            <li class="add-cart-button btn-group"> 
                                <a data-toggle="tooltip" class="btn btn-primary icon" href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>" title="Xem thêm"> 
                                    <i class="fa fa-eye" aria-hidden="true"></i> 
                                </a> </li>
                            </ul>
                          </div>
                          <!-- /.action --> 
                        </div>
                        <!-- /.cart --> 
                      </div>
                      <!-- /.product --> 
                      
                    </div>
                    <!-- /.products --> 
                    </div>
                  </div>
                  </form>
                  <?php }
                    }else{
                        echo "Không có sản phẩm tên này!";
                    }  
                  ?>
                  <!-- /.item -->
                </div>
                <!-- /.row --> 
              </div>
              <!-- /.category-product --> 
              
            </div>
            <!-- /.tab-pane -->
            
            <div class="tab-pane "  id="list-container">
              <div class="category-product">
              <?php
                $sql_pro = "SELECT * FROM tbl_sanpham WHERE tensanpham LIKE '%" .$keyword. "%'";
                $query_pro = mysqli_query($connect, $sql_pro); //phương thức này sẽ chạy câu truy vấn
                 if(mysqli_num_rows($query_pro) > 0){
                  while($list = mysqli_fetch_array($query_pro)){
                    $sql_star = "SELECT ROUND(AVG(rating), 1) as star FROM tbl_review WHERE id_product=" . $list['id_sanpham'];
                    $query_star = mysqli_query($connect, $sql_star);
                    $result_star = mysqli_fetch_array($query_star);
                    $star = $result_star['star'];

                    $query = "SELECT COUNT(*) AS reviews FROM tbl_review WHERE id_product = " . $list['id_sanpham'];
                    $result = mysqli_query($connect, $query);
                    $getdata = mysqli_fetch_array($result);
                    $count = $getdata['reviews'];
                  //để lấy được kết quả truy vấn thì sử dụng phương thức mysqli_fetch_array 
              ?>
                <div class="category-product-inner">
                  <div class="products">
                    <div class="product-list product">
                      <div class="row product-list-row">
                        <div class="col col-sm-3 col-lg-3">
                          <div class="product-image">
                            <div class="image"> <img src="assets/images/menu/<?php echo $list['hinhanh'] ?>"> </div>
                          </div>
                          <!-- /.product-image --> 
                        </div>
                        <!-- /.col -->
                        <div class="col col-sm-9 col-lg-9">
                          <div class="product-info">
                            <h3 class="name"><a href="index.php?quanly=item&id=<?php echo $list['id_sanpham'] ?>">
                              <?php echo $list['tensanpham'] ?>
                            </a></h3>
                            <div class='rating-stars'>
                              <ul id='stars'>
                                  <?php 
                                      for($j=1; $j<=5; $j++){
                                  ?>
                                  <li class='star <?php if($star >= $j) echo 'hover'; ?>' data-value='<?php echo $j ?>' data-product_id="<?php echo $item['id_sanpham'] ?>">
                                      <i class='fa fa-star fa-fw'></i>
                                  </li>
                                  <?php 
                                      }
                                  ?>
                              </ul>
                              <div class="reviews">
                                  <a href="#" class="lnk">(<?php echo $count; ?> Đánh giá)</a>
                              </div>
                          </div>
                            <div class="product-price"> <span class="price"><?php echo number_format($list['giasp'],0,',','.').' VND' ?></span></div>
                            <!-- /.product-price -->
                            <div class="description m-t-10"><?php echo $list['tomtat'] ?></div>
                            <div class="cart clearfix animate-effect">
                              <div class="action">
                                    <form action="page/main/settle.php?idsanpham=<?php echo $list['id_sanpham'] ?>" method="POST">
                                <ul class="list-unstyled">
                                <input type="hidden" value="1" name="quantity">
                                  <li class="add-cart-button btn-group">
                                      <button class="btn btn-primary icon" data-toggle="tooltip" type="submit" title="Thêm giỏ hàng" name="addtocart"> 
                                        <i class="fa fa-shopping-cart"></i> 
                                      </button>
                                      <button class="btn btn-primary cart-btn" type="button">Thêm giỏ hàng</button>
                                  </li>
                                  <li class="add-cart-button btn-group"> 
                                  <button data-toggle="tooltip" class="btn btn-primary icon" type="submit" name="addwishlist" title="Ưa thích"> 
                                      <i class="icon fa fa-heart"></i>
                                  </button> </li>
                                  <li class="add-cart-button btn-group"> 
                                    <a class="btn btn-primary icon" href="index.php?quanly=item&id=<?php echo $list['id_sanpham']; ?>" title="View"> 
                                      <i class="fa fa-eye"></i> 
                                  </a> </li>
                                </ul>
                                    </form>
                              </div>
                              <!-- /.action --> 
                            </div>
                            <!-- /.cart --> 
                            
                          </div>
                          <!-- /.product-info --> 
                        </div>
                        <!-- /.col --> 
                      </div>
                      <!-- /.product-list-row -->
                    </div>
                    <!-- /.product-list --> 
                  </div>
                  <!-- /.products --> 
                </div>
              <?php }
                }else{
                    echo "chưa có sản phẩm!";
                }  
              ?>
                <!-- /.category-product-inner -->
                
              </div>
              <!-- /.category-product --> 
            </div>
            <!-- /.tab-pane #list-container --> 
          </div>
          <!-- /.tab-content -->
       
          <!-- /.filters-container --> 
          
        </div>
        <!-- /.search-result-container --> 
        
      </div>
      <!-- /.col --> 
    </div>
    <!-- /.row --> 
  <!-- /.container --> 
  
</div>
<!-- /.body-content --> 