<div id="hero">
    <div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
        <div class="item" style="background-image: url(assets/images/sliders/S1.jpg); opacity: 0.8;">
            <div class="container-fluid">
                <div class="caption bg-color vertical-center text-left">
                    <div class="slider-header fadeInDown-1">Lao Food</div>
                    <div class="big-text fadeInDown-1"> MÓN ĂN MỚI </div>
                    <div class="excerpt fadeInDown-2 hidden-xs"> <span>Xem những món ăn mới của quán chúng tôi.</span>
                    </div>
                    <div class="button-holder fadeInDown-3"> <a href="#all"
                            class="btn-lg btn btn-uppercase btn-primary shop-now-button">Mua Ngay</a> </div>
                </div>
                <!-- /.caption -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.item -->

        <div class="item" style="background-image: url(assets/images/sliders/S2.jpg); opacity: 0.75;">
            <div class="container-fluid">
                <div class="caption bg-color vertical-center text-left">
                    <div class="slider-header fadeInDown-1">LAO FOOD</div>
                    <div class="big-text fadeInDown-1"> ĐANG HOT </div>
                    <div class="excerpt fadeInDown-2 hidden-xs"> <span>Tìm kiếm menu đang hot ngày này.</span> </div>
                    <div class="button-holder fadeInDown-3"> <a href="#all"
                            class="btn-lg btn btn-uppercase btn-primary shop-now-button">Mua Ngay</a> </div>
                </div>
                <!-- /.caption -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.item -->

    </div>
    <!-- /.owl-carousel -->
</div>
<!-- ========================================= SECTION – HERO : END ========================================= -->

<div class="body-content outer-top-vs" id="top-banner-and-menu">
    <div class="container">
        <div class="row">

            <!-- ============================================== CONTENT ============================================== -->
            <div class="col-xs-12 col-sm-12 col-md-12">
                <!-- ========================================== SECTION – HERO ========================================= -->
                <!-- ============================================== SCROLL TABS ============================================== -->
                <div id="product-tabs-slider" class="scroll-tabs outer-top-vs">
                    <div class="more-info-tab clearfix ">
                        <h3 class="new-product-title pull-left" >Món ăn bạn có thể quan tâm</h3>
                        <ul class="nav nav-tabs nav-tab-line pull-right" id="new-products-1">
                            <li class="active"><a data-transition-type="backSlide" href="#all" data-toggle="tab">All</a>
                            </li>
                            <li><a data-transition-type="backSlide" href="#main-dish" data-toggle="tab">Món chính</a>
                            </li>
                            <li><a data-transition-type="backSlide" href="#drink" data-toggle="tab">Đồ uống</a>
                            </li>
                            <li><a data-transition-type="backSlide" href="#dessert" data-toggle="tab">Ăn vặt</a></li>
                        </ul>
                        <!-- /.nav-tabs -->
                    </div>
                    <div class="tab-content outer-top-xs">
                        <div class="tab-pane in active" id="all">
                            <div class="product-slider">
                                <div class="owl-carousel home-owl-carousel custom-carousel owl-theme">
                            <?php 
                                $sql_pro = "SELECT * FROM tbl_sanpham WHERE tinhtrang=1 ORDER BY tbl_sanpham.id_sanpham DESC LIMIT 10";
                                $query_pro = mysqli_query($connect, $sql_pro);
                                if(mysqli_num_rows($query_pro) > 0){ //để lấy được kết quả truy vấn thì sử dụng phương thức mysqli_fetch_array 
                                    while($item = mysqli_fetch_array($query_pro)){
                                        $sql_star = "SELECT ROUND(AVG(rating), 1) as star FROM tbl_review WHERE id_product=" . $item['id_sanpham'];
                                        $query_star = mysqli_query($connect, $sql_star);
                                        $result_star = mysqli_fetch_array($query_star);
                                        $star = $result_star['star'];
                                    
                            ?>
                                    <div class="item item-carousel">
                                        <div class="products">
                                            <div class="product">
                                                <div class="product-image">
                                                    <div class="image">
                                                        <a
                                                            href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>">
                                                            <img src="assets/images/menu/<?php echo $item['hinhanh']?>">
                                                            <img src="assets/images/menu/<?php echo $item['hinhanh']?>"
                                                                class="hover-image">
                                                        </a>
                                                    </div>
                                                    <!-- /.image -->

                                                    
                                                </div>
                                                <!-- /.product-image -->

                                                <div class="product-info text-left">
                                                    <h3 class="name">
                                                        <a href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>">
                                                            <?php echo $item['tensanpham'] ?>
                                                        </a>
                                                    </h3>
                                                    <div class='rating-stars'>
                                                        <ul id='stars'>
                                                            <?php 
                                                                for($j=1; $j<=5; $j++){
                                                            ?>
                                                            <li class='star <?php if($star >= $j) echo 'hover'; ?>' data-value='<?php echo $j ?>' data-product_id="<?php echo $item['id_sanpham'] ?>">
                                                                <i class='fa fa-star fa-fw'></i>
                                                            </li>
                                                            <?php 
                                                                }
                                                            ?>
                                                        </ul>
                                                    </div>
                                                    <div class="description"></div>
                                                    <div class="product-price">
                                                        <span
                                                            class="price"><?php echo number_format($item['giasp'],0,',','.').' VND' ?></span>
                                                    </div>
                                                    <!-- /.product-price -->

                                                </div>
                                                <!-- /.product-info -->
                                                <div class="cart clearfix animate-effect">
                                                    <div class="action">
                                                        <form action="page/main/settle.php?idsanpham=<?php echo $item['id_sanpham'] ?>" method="POST">
                                                            <input type="hidden" value="1" name="quantity">
                                                            <ul class="list-unstyled">
                                                                <li class="add-cart-button btn-group">
                                                                    <button data-toggle="tooltip" class="btn btn-primary icon" type="submit" name="addtocart" title="ThêmGiỏHàng"> 
                                                                        <i class="fa fa-shopping-cart"></i> </button>
                                                                    <button class="btn btn-primary cart-btn"
                                                                        type="button">Add to cart</button>
                                                                </li>
                                                                <li class="add-cart-button btn-group"> 
                                                                    <button data-toggle="tooltip" class="btn btn-primary icon" type="submit" name="addwishlist" title="Ưa thích"> 
                                                                        <i class="icon fa fa-heart"></i>
                                                                    </button> </li>
                                                                <li class="add-cart-button btn-group"> 
                                                                    <a data-toggle="tooltip" class="btn btn-primary icon" href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>" title="Xem thêm"> 
                                                                        <i class="fa fa-eye" aria-hidden="true"></i> 
                                                                    </a> </li>
                                                            </ul>
                                                        </form>
                                                    </div>
                                                    <!-- /.action -->
                                                </div>
                                                <!-- /.cart -->
                                            </div>
                                            <!-- /.product -->

                                        </div>
                                        <!-- /.products -->
                                    </div>
                                    <!-- /.item -->
                                    <?php }
                                    }else{
                                        echo "chưa có sản phẩm!";
                                    }  
                                ?>
                                </div>
                                <!-- /.home-owl-carousel -->
                            </div>
                            <!-- /.product-slider -->
                        </div>
                        <!-- /.tab-pane -->

                        <div class="tab-pane" id="main-dish">
                            <div class="product-slider">
                                <div class="owl-carousel home-owl-carousel custom-carousel owl-theme">
                                    <?php
                                $sql_dish = "SELECT * FROM tbl_sanpham WHERE category=1 AND tinhtrang=1 LIMIT 10";
                                $query_dish = mysqli_query($connect, $sql_dish);
                                    if(mysqli_num_rows($query_dish) > 0){
                                        while($item = mysqli_fetch_array($query_dish)){
                                            $sql_star = "SELECT ROUND(AVG(rating), 1) as star FROM tbl_review WHERE id_product=" . $item['id_sanpham'];
                                            $query_star = mysqli_query($connect, $sql_star);
                                            $result_star = mysqli_fetch_array($query_star);
                                            $star = $result_star['star'];
                                ?>
                                    <div class="item item-carousel">
                                        <div class="products">
                                            <div class="product">
                                                <div class="product-image">
                                                    <div class="image">
                                                        <a
                                                            href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>">
                                                            <img src="assets/images/menu/<?php echo $item['hinhanh']?>">
                                                            <img src="assets/images/menu/<?php echo $item['hinhanh']?>"
                                                                class="hover-image">
                                                        </a>

                                                    </div>
                                                    <!-- /.image -->

                                                </div>
                                                <!-- /.product-image -->

                                                <div class="product-info text-left">
                                                    <h3 class="name"><a
                                                            href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>">
                                                            <?php echo $item['tensanpham'] ?></a>
                                                    </h3>
                                                    <div class='rating-stars'>
                                                        <ul id='stars'>
                                                            <?php 
                                                                for($j=1; $j<=5; $j++){
                                                            ?>
                                                            <li class='star <?php if($star >= $j) echo 'hover'; ?>' data-value='<?php echo $j ?>' data-product_id="<?php echo $item['id_sanpham'] ?>">
                                                                <i class='fa fa-star fa-fw'></i>
                                                            </li>
                                                            <?php 
                                                                }
                                                            ?>
                                                        </ul>
                                                    </div>
                                                    <div class="description"></div>
                                                    <div class="product-price">
                                                        <span
                                                            class="price"><?php echo number_format($item['giasp'],0,',','.').' VND' ?></span>
                                                    </div>
                                                    <!-- /.product-price -->

                                                </div>
                                                <!-- /.product-info -->
                                                <div class="cart clearfix animate-effect">
                                                    <div class="action">
                                                    <form action="page/main/settle.php?idsanpham=<?php echo $item['id_sanpham'] ?>" method="POST">
                                                            <input type="hidden" value="1" name="quantity">
                                                            <ul class="list-unstyled">
                                                                <li class="add-cart-button btn-group">
                                                                    <button data-toggle="tooltip" class="btn btn-primary icon" type="submit" name="addtocart" title="ThêmGiỏHàng"> 
                                                                        <i class="fa fa-shopping-cart"></i> </button>
                                                                    <button class="btn btn-primary cart-btn"
                                                                        type="button">Add to cart</button>
                                                                </li>
                                                                <li class="add-cart-button btn-group"> 
                                                                    <button data-toggle="tooltip" class="btn btn-primary icon" type="submit" name="addwishlist" title="Ưa thích"> 
                                                                        <i class="icon fa fa-heart"></i>
                                                                    </button> </li>
                                                                <li class="add-cart-button btn-group"> 
                                                                    <a data-toggle="tooltip" class="btn btn-primary icon" href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>" title="Xem thêm"> 
                                                                        <i class="fa fa-eye" aria-hidden="true"></i> 
                                                                    </a> </li>
                                                            </ul>
                                                        </form>
                                                    </div>
                                                    <!-- /.action -->
                                                </div>
                                                <!-- /.cart -->
                                            </div>
                                            <!-- /.product -->

                                        </div>
                                        <!-- /.products -->
                                    </div>
                                    <?php }
                                    }else{
                                        echo "chưa có sản phẩm!";
                                    }  
                                ?>
                                    <!-- /.item -->
                                </div>
                                <!-- /.home-owl-carousel -->
                            </div>
                            <!-- /.product-slider -->
                        </div>
                        <!-- /.tab-pane -->

                        <div class="tab-pane" id="drink">
                            <div class="product-slider">
                                <div class="owl-carousel home-owl-carousel custom-carousel owl-theme">
                                    <?php
                                    $sql_drink = "SELECT * FROM tbl_sanpham WHERE category=2 LIMIT 10";
                                    $query_drink = mysqli_query($connect, $sql_drink);
                                    if(mysqli_num_rows($query_drink) > 0){
                                        while($item = mysqli_fetch_array($query_drink)){
                                            $sql_star = "SELECT ROUND(AVG(rating), 1) as star FROM tbl_review WHERE id_product=" . $item['id_sanpham'];
                                            $query_star = mysqli_query($connect, $sql_star);
                                            $result_star = mysqli_fetch_array($query_star);
                                            $star = $result_star['star'];
                                ?>
                                    <div class="item item-carousel">
                                        <div class="products">
                                            <div class="product">
                                                <div class="product-image">
                                                    <div class="image">
                                                        <a
                                                            href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>">
                                                            <img src="assets/images/menu/<?php echo $item['hinhanh']?>">
                                                            <img src="assets/images/menu/<?php echo $item['hinhanh']?>"
                                                                class="hover-image">
                                                        </a>

                                                    </div>
                                                    <!-- /.image -->

                                                </div>
                                                <!-- /.product-image -->

                                                <div class="product-info text-left">
                                                    <h3 class="name"><a
                                                            href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>">
                                                            <?php echo $item['tensanpham'] ?></a>
                                                    </h3>
                                                    <div class='rating-stars'>
                                                        <ul id='stars'>
                                                            <?php 
                                                                for($j=1; $j<=5; $j++){
                                                            ?>
                                                            <li class='star <?php if($star >= $j) echo 'hover'; ?>' data-value='<?php echo $j ?>' data-product_id="<?php echo $item['id_sanpham'] ?>">
                                                                <i class='fa fa-star fa-fw'></i>
                                                            </li>
                                                            <?php 
                                                                }
                                                            ?>
                                                        </ul>
                                                    </div>
                                                    <div class="description"></div>
                                                    <div class="product-price">
                                                        <span
                                                            class="price"><?php echo number_format($item['giasp'],0,',','.').' VND' ?></span>
                                                    </div>
                                                    <!-- /.product-price -->

                                                </div>
                                                <!-- /.product-info -->
                                                <div class="cart clearfix animate-effect">
                                                    <div class="action">
                                                    <form action="page/main/settle.php?idsanpham=<?php echo $item['id_sanpham'] ?>" method="POST">
                                                            <input type="hidden" value="1" name="quantity">
                                                            <ul class="list-unstyled">
                                                                <li class="add-cart-button btn-group">
                                                                    <button data-toggle="tooltip" class="btn btn-primary icon" type="submit" name="addtocart" title="ThêmGiỏHàng"> 
                                                                        <i class="fa fa-shopping-cart"></i> </button>
                                                                    <button class="btn btn-primary cart-btn"
                                                                        type="button">Add to cart</button>
                                                                </li>
                                                                <li class="add-cart-button btn-group"> 
                                                                    <button data-toggle="tooltip" class="btn btn-primary icon" type="submit" name="addwishlist" title="Ưa thích"> 
                                                                        <i class="icon fa fa-heart"></i>
                                                                    </button> </li>
                                                                <li class="add-cart-button btn-group"> 
                                                                    <a data-toggle="tooltip" class="btn btn-primary icon" href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>" title="Xem thêm"> 
                                                                        <i class="fa fa-eye" aria-hidden="true"></i> 
                                                                    </a> </li>
                                                            </ul>
                                                        </form>
                                                    </div>
                                                    <!-- /.action -->
                                                </div>
                                                <!-- /.cart -->
                                            </div>
                                            <!-- /.product -->

                                        </div>
                                        <!-- /.products -->
                                    </div>
                                    <?php }
                                    }else{
                                        echo "chưa có sản phẩm!";
                                    }  
                                ?>
                                    <!-- /.item -->
                                </div>
                                <!-- /.home-owl-carousel -->
                            </div>
                            <!-- /.product-slider -->
                        </div>
                        <!-- /.tab-pane -->

                        <div class="tab-pane" id="dessert">
                            <div class="product-slider">
                                <div class="owl-carousel home-owl-carousel custom-carousel owl-theme">
                                    <?php
                                    $sql_drink = "SELECT * FROM tbl_sanpham WHERE category=3 LIMIT 10";
                                    $query_drink = mysqli_query($connect, $sql_drink);
                                    if(mysqli_num_rows($query_drink) > 0){
                                        while($item = mysqli_fetch_array($query_drink)){
                                            $sql_star = "SELECT ROUND(AVG(rating), 1) as star FROM tbl_review WHERE id_product=" . $item['id_sanpham'];
                                            $query_star = mysqli_query($connect, $sql_star);
                                            $result_star = mysqli_fetch_array($query_star);
                                            $star = $result_star['star'];
                                ?>
                                    <div class="item item-carousel">
                                        <div class="products">
                                            <div class="product">
                                                <div class="product-image">
                                                    <div class="image">
                                                        <a href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>">
                                                            <img src="assets/images/menu/<?php echo $item['hinhanh']?>">
                                                            <img src="assets/images/menu/<?php echo $item['hinhanh']?>" class="hover-image">
                                                        </a>

                                                    </div>
                                                    <!-- /.image -->

                                                </div>
                                                <!-- /.product-image -->

                                                <div class="product-info text-left">
                                                    <h3 class="name"><a
                                                            href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>">
                                                            <?php echo $item['tensanpham'] ?></a>
                                                    </h3>
                                                    <div class='rating-stars'>
                                                        <ul id='stars'>
                                                            <?php 
                                                                for($j=1; $j<=5; $j++){
                                                            ?>
                                                            <li class='star <?php if($star >= $j) echo 'hover'; ?>' data-value='<?php echo $j ?>' data-product_id="<?php echo $item['id_sanpham'] ?>">
                                                                <i class='fa fa-star fa-fw'></i>
                                                            </li>
                                                            <?php 
                                                                }
                                                            ?>
                                                        </ul>
                                                    </div>
                                                    <div class="description"></div>
                                                    <div class="product-price">
                                                        <span
                                                            class="price"><?php echo number_format($item['giasp'],0,',','.').' VND' ?></span>
                                                    </div>
                                                    <!-- /.product-price -->

                                                </div>
                                                <!-- /.product-info -->
                                                <div class="cart clearfix animate-effect">
                                                    <div class="action">
                                                    <form action="page/main/settle.php?idsanpham=<?php echo $item['id_sanpham'] ?>" method="POST">
                                                            <input type="hidden" value="1" name="quantity">
                                                            <ul class="list-unstyled">
                                                                <li class="add-cart-button btn-group">
                                                                    <button data-toggle="tooltip" class="btn btn-primary icon" type="submit" name="addtocart" title="ThêmGiỏHàng"> 
                                                                        <i class="fa fa-shopping-cart"></i> </button>
                                                                    <button class="btn btn-primary cart-btn"
                                                                        type="button">Add to cart</button>
                                                                </li>
                                                                <li class="add-cart-button btn-group"> 
                                                                    <button data-toggle="tooltip" class="btn btn-primary icon" type="submit" name="addwishlist" title="Ưa thích"> 
                                                                        <i class="icon fa fa-heart"></i>
                                                                    </button> </li>
                                                                <li class="add-cart-button btn-group"> 
                                                                    <a data-toggle="tooltip" class="btn btn-primary icon" href="index.php?quanly=item&id=<?php echo $item['id_sanpham'] ?>" title="Xem thêm"> 
                                                                        <i class="fa fa-eye" aria-hidden="true"></i> 
                                                                    </a> </li>
                                                            </ul>
                                                        </form>
                                                    </div>
                                                    <!-- /.action -->
                                                </div>
                                                <!-- /.cart -->
                                            </div>
                                            <!-- /.product -->

                                        </div>
                                        <!-- /.products -->
                                    </div>
                                    <?php }
                                    }else{
                                        echo "chưa có sản phẩm!";
                                    }  
                                ?>
                                    <!-- /.item -->
                                </div>
                                <!-- /.home-owl-carousel -->
                            </div>
                            <!-- /.product-slider -->
                        </div>
                        <!-- /.tab-pane -->

                    </div>
                    <!-- /.tab-content -->
                </div>
                <!-- /.scroll-tabs -->

            </div>
            <!-- /.homebanner-holder -->
            <!-- ============================================== CONTENT : END ============================================== -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
</div>
<!-- /#top-banner-and-menu -->