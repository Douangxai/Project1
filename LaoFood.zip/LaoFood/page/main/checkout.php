<div class="breadcrumb">
    <div class="container">
        <div class="breadcrumb-inner">
            <ul class="list-inline list-unstyled">
                <li><a href="#">Home</a></li>
                <li class='active'>Thanh toán</li>
            </ul>
        </div><!-- /.breadcrumb-inner -->
    </div><!-- /.container -->
</div><!-- /.breadcrumb -->

<div class="body-content">
    <div class="container">
        <div class="checkout-box ">
            <div class="row">
                <div class="col-xs-12 col-sm-9 col-md-9 rht-col">
                    <div class="panel-group checkout-steps" id="accordion">
                        <!-- checkout-step-02  -->
                        <div class="panel panel-default checkout-step-02">
                            <div class="panel-heading">
                                <h4 class="unicase-checkout-title">
                                    <a data-toggle="collapse" class="collapsed" data-parent="#accordion"
                                        href="#collapseTwo">
                                        <span>1</span>Thông tin hóa đơn
                                    </a>
                                </h4>
                            </div>
                            <div id="collapseTwo" class="panel-collapse collapse in">
                            <?php
                            if(isset($_SESSION['sign-in'])){
                                $id_account = $_SESSION['id_account'];
                                if(isset($_POST['checkout'])){
                                    $address = $_POST['village']. ", ".$_POST['street'].", ".$_POST['house'];
                                    $code_order = rand(0,9999);
                                    $insert_order = "INSERT INTO tbl_order(id_account,code_order,order_status,address) 
                                                        VALUE('".$id_account."','".$code_order."',1,'".$address."')";
                                    $order_query = mysqli_query($connect,$insert_order);
                                    if($insert_order){
                                        // thêm giỏ hàng chi tiết
                                        foreach($_SESSION['cart'] as $key => $value){
                                            $id_sanpham = $value['id'];
                                            $soluong = $value['soluong'];
                                            $insert_cart = "INSERT INTO tbl_cart(id_sanpham,code_order,soluong) 
                                                            VALUE('".$id_sanpham."','".$code_order."','".$soluong."')";
                                            mysqli_query($connect, $insert_cart);
                                        }
                                    }
                                    unset($_SESSION['cart']);
                                
                            }
                                    $sql_orders = "SELECT * FROM tbl_order WHERE tbl_order.id_account=".$id_account." ORDER BY date DESC";
                                    $query_orders = mysqli_query($connect, $sql_orders);
                                    if(mysqli_num_rows($query_orders) > 0){
                                        while($order = mysqli_fetch_array($query_orders)){
                                            
                            ?>
                                <div class="panel-body" style="border:1px solid #555; border-radius:1rem; margin:1rem">
                                <div><?php echo $order['date']; ?></div>
                                <hr>
                                    <?php
									
										$sql_order = "SELECT * FROM tbl_order, tbl_cart, tbl_sanpham 
                                                    WHERE tbl_order.id_account='".$id_account.
                                                    "'AND tbl_order.code_order=tbl_cart.code_order AND
                                                    tbl_order.date='".$order['date']."' AND tbl_cart.id_sanpham=tbl_sanpham.id_sanpham ORDER BY date DESC";
										$query_order = mysqli_query($connect, $sql_order);
                                        $i=0;
										$total=0;
											while($list = mysqli_fetch_array($query_order)){
												$price = $list['soluong']*$list['giasp'];
												$total+=$price;
												$i++;
									?>
                                    <div class="cart-item product-summary">
                                        <div class="row">
                                            <div class="col-xs-4">
                                                <div class="image">
                                                        <img src="assets/images/menu/<?php echo $list['hinhanh']; ?>"
                                                            width="100px">
                                                </div>
                                            </div>
                                            <div class="col-xs-5">
                                                <h4 class="name" style="color: #0f6cb2">
                                                    <?php echo $list['tensanpham']; ?>
                                                </h4>
                                            </div>
                                            <div class="col-xs-3">
                                                <h5 style="color: #ff7878"><?php echo $list['soluong']."x".$list['giasp']; ?> VND</h5>
                                            </div>
                                        </div>
                                </div>
                                    <!-- /.cart-item -->
                                    <div class="clearfix"></div>
                                    <hr>
                                    <?php
				}
			?>
                                    <div class="clearfix cart-total">
                                        <div class="pull-right" style="font-size: 15px; color: #84b943;"><b>
                                            <span class="text">Tổng cộng: </span>
                                            <span class='price'>
                                                <?php echo number_format($total,0,',','.').' VND'; ?>
                                            </span></b>
                                        </div>
                                        <div class="clearfix"></div>
                                        <hr>

                                    </div>
                                </div>
                                    <!-- /.cart-total-->
                                    <?php }
				} else {
					echo "<h2 style='text-align: center;'>Chưa có hóa đơn</h2>";
				}} else {
            ?>
                <div style="text-align: center;">
                    <h3> Chưa đăng nhập tài khoản </h3>
                    <a href="index.php?quanly=sign-in" class="btn-upper btn btn-primary checkout-page-button">
                        ĐĂNG NHẬP NGAY
                    </a>
                    <h5>
                        Khi cần trợ giúp vui lòng gọi <span style="color: #0f6cb2">+ (84) 0827 852 316</span>
                        hoặc <span style="color: #0f6cb2">+ (856) 20 9575 5332</span> (7h30 - 22h)
                    </5>
                </div>
            <?php
				}
			?>
                                
                            </div>
                        </div>
                        <!-- checkout-step-02  -->



                    </div><!-- /.checkout-steps -->
                </div>
            </div><!-- /.row -->
        </div><!-- /.checkout-box -->