<div class="breadcrumb">
    <div class="container">
        <div class="breadcrumb-inner">
            <ul class="list-inline list-unstyled">
                <li><a href="#">Home</a></li>
                <li class='active'>Tin tức</li>
            </ul>
        </div><!-- /.breadcrumb-inner -->
    </div><!-- /.container -->
</div><!-- /.breadcrumb -->
<div class="body-content">
    <div class="container">
        <div class="row">
            <div class="blog-page">
                <div class="col-xs-12 col-sm-12 col-md-12">
                <?php
                $sql_page = mysqli_query($connect, "SELECT * FROM blog");
                $row_count = mysqli_num_rows($sql_page);
                $page = ceil($row_count/3);
                if(isset($_GET['page'])){
                      $pages = $_GET['page'];
                  } else {
                      $pages = 1;
                  } if($pages == '' || $pages == 1){
                      $begin = 0;
                  } else {
                      $begin = ($pages*3)-3;
                  }
                    $sql_blog = "SELECT * FROM blog ORDER BY date DESC LIMIT $begin,3";
                    $query_blog = mysqli_query($connect, $sql_blog);
                    while($row = mysqli_fetch_array($query_blog)) {
                ?>
                    <div class="blog-post outer-top-bd  wow fadeInUp">
                        <a href="index.php?quanly=news&id=<?php echo $row['id'] ?>">
                            <img class="img-responsive" src="assets/images/blog-post/<?php echo $row['hinhanh'] ?>" style="height: 490px; margin: auto;">
                        </a>
                        <h1><a href="index.php?quanly=news&id=<?php echo $row['id'] ?>"><?php echo $row['tenbaiviet'] ?></a></h1>
                        <span class="date-time"><?php echo $row['date'] ?></span>
                        <p><?php echo $row['tomtat'] ?></p>
                        <a href="index.php?quanly=news&id=<?php echo $row['id'] ?>" class="btn btn-upper btn-primary read-more">ĐỌC THÊM</a>
                    </div>
                    <?php } ?>
                    <div class="clearfix blog-pagination filters-container  wow fadeInUp"
                        style="padding:0px; background:none; box-shadow:none; margin-top:15px; border:none">

                        <div class="text-right">
                            <div class="pagination-container">
                                <ul class="list-inline list-unstyled">
                                    <li class="prev" style="display:<?php if($page==1) echo 'none'; else echo ''; ?>">
                                        <a href="index.php?quanly=blog&page=<?php if($pages>1) echo $pages-1; else echo 1; ?>">
                                        <i class="fa fa-angle-left"></i>
                                    </a></li>
                                    <?php for($i=1; $i<=$page; $i++){ ?>
                                    <li class="active" style="display:<?php if($page==1) echo 'none'; else echo ''; ?>">
                                        <a href="index.php?quanly=blog&page=<?php echo $i ?>"><?php echo $i ?></a>
                                    </li>
                                    <?php } ?>
                                    <li class="next" style="display:<?php if($page==1) echo 'none'; else echo ''; ?>">
                                        <a href="index.php?quanly=blog&page=<?php if($pages==$page) echo $pages; else echo $pages+1; ?>">
                                        <i class="fa fa-angle-right"></i>
                                    </a></li>
                                </ul><!-- /.list-inline -->
                            </div><!-- /.pagination-container -->
                        </div><!-- /.text-right -->

                    </div><!-- /.filters-container -->
                </div>
            </div>
        </div>
    </div>
</div>