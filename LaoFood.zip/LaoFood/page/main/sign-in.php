
<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<ul class="list-inline list-unstyled">
				<li><a href="home.html">Home</a></li>
				<li class='active'>Login</li>
			</ul>
		</div><!-- /.breadcrumb-inner -->
	</div><!-- /.container -->
</div><!-- /.breadcrumb -->

<div class="body-content">
	<div class="container">
		<div class="sign-in-page">
			<div class="row">
				<!-- Sign-in -->			
				
<div class="col-md-6 col-sm-6 sign-in">
	<h4 class="">Đăng nhập</h4>
	<p class="">Xin chào, đăng nhập tài khoản của bạn.</p>
	<div class="social-sign-in outer-top-xs">
		<a href="#" class="facebook-sign-in"><i class="fa fa-facebook"></i> Đăng nhập bằng Facebook</a>
		<a href="#" class="twitter-sign-in"><i class="fa fa-twitter"></i> Đăng nhập bằng Twitter</a>
	</div>
	<form class="register-form outer-top-xs" role="form" method="POST" action="page/main/settle.php" autocomplete="off">
		<div class="form-group">
		    <label class="info-title" for="Email1">Địa chỉ Email <span>*</span></label>
		    <input type="email" class="form-control unicase-form-control text-input" id="Email1" name="Email1" required >
		</div>
	  	<div class="form-group">
		    <label class="info-title" for="Password1">Mật khẩu <span>*</span></label>
		    <input type="password" class="form-control unicase-form-control text-input" id="Password1" name="Password1" required >
		</div>
		<div class="radio outer-xs">
		  	<label>
		    	<input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">Hãy nhớ tôi!
		  	</label>
		  	<a href="#" class="forgot-password pull-right">Quên mật khẩu !?</a>
		</div>
	  	<button type="submit" name="login" class="btn-upper btn btn-primary checkout-page-button">Đăng nhập</button>
	</form>					
</div>
<!-- Sign-in -->

<!-- create a new account -->
<div class="col-md-6 col-sm-6 create-new-account">
	<h4 class="checkout-subtitle">Tạo tài khoản mới</h4>
	<p class="text title-tag-line">Tạo tài khoản mới của bạn.</p>
	<form class="register-form outer-top-xs" role="form" method="POST" action="page/main/settle.php" autocomplete="off">
		<div class="form-group">
	    	<label class="info-title" for="Email2">Địa chỉ Email <span>*</span></label>
	    	<input type="email" class="form-control unicase-form-control text-input" id="Email2" name="Email2" required >
	  	</div>
        <div class="form-group">
		    <label class="info-title" for="fullname">Tên <span>*</span></label>
		    <input type="text" class="form-control unicase-form-control text-input" id="fullname" name="fullname" required >
		</div>
        <div class="form-group">
		    <label class="info-title" for="phone">Số điện thoại <span>*</span></label>
		    <input type="text" class="form-control unicase-form-control text-input" id="phone" name="phone" required >
		</div>
        <div class="form-group">
		    <label class="info-title" for="password">Mật khẩu <span>*</span></label>
		    <input type="password" class="form-control unicase-form-control text-input" id="password" name="password" required >
		</div>
         <div class="form-group">
		    <label class="info-title" for="repassword">Xác nhận mật khẩu lại <span>*</span></label>
		    <input type="password" class="form-control unicase-form-control text-input" id="repassword" name="repassword" required >
		</div>
	  	<button type="submit" name="sign-up" class="btn-upper btn btn-primary checkout-page-button">Đăng ký</button>
	</form>
	
	
</div>	
<!-- create a new account -->			</div><!-- /.row -->
		</div><!-- /.sigin-in-->
