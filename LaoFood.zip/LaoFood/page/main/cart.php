<div class="breadcrumb">
    <div class="container">
        <div class="breadcrumb-inner">
            <ul class="list-inline list-unstyled">
                <li><a href="#">Home</a></li>
                <li class='active'>Giỏ hàng</li>
            </ul>
        </div><!-- /.breadcrumb-inner -->
    </div><!-- /.container -->
</div><!-- /.breadcrumb -->

<div class="body-content outer-top-xs">
    <div class="container">
        <div class="row ">
            <?php
                if(isset($_SESSION['cart'])){
            ?>
            <form method="POST" action="index.php?quanly=checkout">
                <div class="shopping-cart">
                    <div class="shopping-cart-table ">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th class="cart-romove item">Xóa sản phẩm</th>
                                        <th class="cart-description item">Hình ảnh sản phẩm</th>
                                        <th class="cart-product-name item">tên sản phẩm</th>
                                        <th class="cart-qty item">Số lượng</th>
                                        <th class="cart-sub-total item">Giá cả</th>
                                        <th class="cart-total last-item">Thành tiền</th>
                                    </tr>
                                </thead><!-- /thead -->
                                <?php
                                    $total=0;
                                    $i = 0;
                                    foreach($_SESSION['cart'] as $cart_item){
                                        $price = $cart_item['soluong']*$cart_item['giasp'];
                                        $total+=$price;
                                        $i++;

                                        $sql_star = "SELECT ROUND(AVG(rating), 1) as star FROM tbl_review WHERE id_product=" . $cart_item['id'];
                                        $query_star = mysqli_query($connect, $sql_star);
                                        $result_star = mysqli_fetch_array($query_star);
                                        $star = $result_star['star'];
        
                                        $query = "SELECT COUNT(*) AS reviews FROM tbl_review WHERE id_product = " . $cart_item['id'];
                                        $result = mysqli_query($connect, $query);
                                        $getdata = mysqli_fetch_array($result);
                                        $count = $getdata['reviews'];   
                            ?>
                                <tbody>
                                    <tr>
                                        <td class="romove-item">
                                            <a href="page/main/settle.php?del=<?php echo $cart_item['id'] ?>"
                                                title="cancel" class="icon">
                                                <i class="fa fa-trash-o"></i></a>
                                        </td>
                                        <td class="cart-image">
                                            <a class="entry-thumbnail"
                                                href="index.php?quanly=item&id=<?php echo $cart_item['id']; ?>">
                                                <img src="assets/images/menu/<?php echo $cart_item['hinhanh']; ?>"
                                                    alt="">
                                            </a>
                                        </td>
                                        <td class="cart-product-name-info">
                                            <h4 class='cart-product-description'>
                                                <a href="index.php?quanly=item&id=<?php echo $cart_item['id']; ?>">
                                                    <?php echo $cart_item['tensanpham']; ?>
                                                </a>
                                            </h4>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class='rating-stars'>
                                                        <ul id='stars'>
                                                            <?php 
                                                            for($j=1; $j<=5; $j++){
                                                        ?>
                                                            <li class='star <?php if($star >= $j) echo 'hover'; ?>'
                                                                data-value='<?php echo $j ?>'
                                                                data-product_id="<?php echo $row_item['id_sanpham'] ?>">
                                                                <i class='fa fa-star fa-fw'></i>
                                                            </li>
                                                            <?php 
                                                            }
                                                        ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="reviews">
                                                        (<?php echo $count; ?> Đánh giá)
                                                    </div>
                                                </div>
                                            </div><!-- /.row -->
                                            <div class="cart-product-info">
                                                <span class="product-color">Loại sản phẩm:<span>
                                                        <?php 
                                                    switch ($cart_item['category']) {
                                                        case 1: echo "Món chính"; break;
                                                        case 2: echo "Đồ uống"; break;
                                                        case 3: echo "Món ăn tráng miệng"; break;
                                                    }
                                                ?>
                                            </div>
                                        </td>
                                        <td class="cart-product-quantity">
                                            <div class="quant-input">
                                                <div class="arrows">
                                                    <div class="arrow plus gradient">
                                                        <a
                                                            href="page/main/settle.php?cong=<?php echo $cart_item['id'] ?>">
                                                            <span class="ir"><i class="icon fa fa-sort-asc"></i></span>
                                                        </a>
                                                    </div>
                                                    <div class="arrow minus gradient">
                                                        <a href="page/main/settle.php?tru=<?php echo $cart_item['id'] ?>">
                                                            <span class="ir"><i class="icon fa fa-sort-desc"></i></span>
                                                        </a>
                                                    </div>

                                                </div>
                                                <input type="text" value="<?php echo $cart_item['soluong']; ?>">
                                            </div>
                                        </td>

                                        <td class="cart-product-sub-total">
                                            <span
                                                class="cart-sub-total-price"><?php echo number_format($cart_item['giasp'],0,',','.').' vnd'; ?></span>
                                        </td>
                                        <td class="cart-product-grand-total">
                                            <span
                                                class="cart-grand-total-price"><?php echo number_format($price,0,',','.').' vnd'; ?></span>
                                        </td>

                                    </tr>
                                </tbody><!-- /tbody -->
                                <?php
				}
			?>
                                <tfoot>
                                    <tr>
                                        <td colspan="7">
                                            <div class="shopping-cart-btn">
                                                <span class="">
                                                    <a href="index.php" class="btn btn-upper btn-primary outer-left-xs">
                                                        Tiếp tục mua sắm
                                                    </a>
                                                    <a href="page/main/settle.php?delete=1"
                                                        class="btn btn-upper btn-primary pull-right outer-right-xs">
                                                        Xóa giỏ hàng
                                                    </a>
                                                </span>
                                            </div><!-- /.shopping-cart-btn -->
                                        </td>
                                    </tr>
                                </tfoot>
                            </table><!-- /table -->
                        </div>
                    </div><!-- /.shopping-cart-table -->
                    <div class="col-md-4 col-sm-12 estimate-ship-tax">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>
                                        <span class="estimate-title">Địa chỉ giao hàng</span>
                                        <p>Nhập điểm đến của bạn để nhận vận chuyển.</p>
                                    </th>
                                </tr>
                            </thead><!-- /thead -->
                            <tbody>
                                <tr>
                                    <td>
                                        <div class="form-group">
                                            <label class="info-title control-label">Quận <span>*</span></label>
                                            <select class="form-control unicase-form-control selectpicker" name="village" required>
                                                <option disabled selected value>--Chọn Phường/ Xã--</option>
                                                <option>Phường Hoà Hải</option>
                                                <option>Phường Hòa Quý</option>
                                                <option>Phường Khuê Mỹ</option>
                                                <option>Phường Mỹ An</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="info-title control-label">Đường <span>*</span></label>
                                            <input type="text" class="form-control unicase-form-control text-input" name="street" required>
                                        </div>
                                        <div class="form-group">
                                            <label class="info-title control-label">Số nhà/Số phòng
                                                <span>*</span></label>
                                            <input type="text" class="form-control unicase-form-control text-input" name="house" required>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div><!-- /.estimate-ship-tax -->

                    <div class="col-md-4 col-sm-12 estimate-ship-tax">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>
                                        <span class="estimate-title">Mã giảm giá</span>
                                        <p>Nhập mã phiếu giảm giá của bạn nếu bạn có.</p>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <div class="form-group">
                                            <input type="text" class="form-control unicase-form-control text-input"
                                                placeholder="Mã giảm giá của bạn..">
                                        </div>
                                        <div class="clearfix pull-right">
                                            <button type="submit" class="btn-upper btn btn-primary">
                                                ÁP DỤNG PHIẾU GIẢM GIÁ
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody><!-- /tbody -->
                        </table><!-- /table -->
                    </div><!-- /.estimate-ship-tax -->

                    <div class="col-md-4 col-sm-12 cart-shopping-total">

                        <table class="table">
                            <thead>
                                <tr>
                                    <th>
                                        <div class="cart-sub-total">
                                            Tổng phụ<span
                                                class="inner-left-md"><?php echo number_format($total,0,',','.').' VND'; ?></span>
                                        </div>
                                        <div class="cart-grand-total">
                                            Tổng cộng<span
                                                class="inner-left-md"><?php echo number_format($total,0,',','.').' VND'; ?></span>
                                        </div>
                                    </th>
                                </tr>
                            </thead><!-- /thead -->
                            <tbody>
                                <tr>
                                    <td>
                                        <div class="cart-checkout-btn pull-right">
                                            <?php
                                            if(isset($_SESSION['sign-in'])){
                                        ?>
                                            <button type="submit" class="btn btn-primary checkout-btn" name="checkout">
                                                THANH TOÁN
                                            </button>
                                            <?php
                                            }else { 
                                        ?>
                                            <a href="index.php?quanly=sign-in" class="btn btn-primary checkout-btn">
                                                ĐĂNG NHẬP ĐỂ THANH TOÁN
                                            </a>
                                            <?php
                                            }
                                        ?>
                                        </div>
                                    </td>
                                </tr>
                            </tbody><!-- /tbody -->
                        </table><!-- /table -->
                    </div><!-- /.cart-shopping-total -->
                </div><!-- /.shopping-cart -->
            </form>
        </div> <!-- /.row -->
        <?php
            } else { 
        ?>
        <div style="text-align: center;">
            <h3> Không có sản phẩm nào trong giỏ hàng </h3>
            <a href="index.php" class="btn btn-primary checkout-btn">
                Về trang chủ
            </a>
            <h5>
                Khi cần trợ giúp vui lòng gọi <span style="color: #0f6cb2">+ (84) 0827 852 316</span>
                hoặc <span style="color: #0f6cb2">+ (856) 20 9575 5332</span> (7h30 - 22h)
            </5>
        </div>
        <?php        
            }
        ?>
    </div>
</div>