<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<ul class="list-inline list-unstyled">
				<li><a href="home.html">Home</a></li>
				<li class='active'>Ưa thích</li>
			</ul>
		</div><!-- /.breadcrumb-inner -->
	</div><!-- /.container -->
</div><!-- /.breadcrumb -->

<div class="body-content">
	<div class="container">
		<div class="my-wishlist-page">
			<div class="row">
				<div class="col-md-12 my-wishlist">
	<div class="table-responsive">
		<table class="table">
			<thead>
				<tr>
					<th colspan="4" class="heading-title">Sản phẩm ưa thích</th>
				</tr>
			</thead>
			<?php
				if(isset($_SESSION['wishlist'])){
					$i = 0;
					foreach($_SESSION['wishlist'] as $wish_item){
						$sql_star = "SELECT ROUND(AVG(rating), 1) as star FROM tbl_review WHERE id_product=" . $wish_item['id'];
						$query_star = mysqli_query($connect, $sql_star);
						$result_star = mysqli_fetch_array($query_star);
						$star = $result_star['star'];

						$query = "SELECT COUNT(*) AS reviews FROM tbl_review WHERE id_product = " . $wish_item['id'];
						$result = mysqli_query($connect, $query);
						$getdata = mysqli_fetch_array($result);
						$count = $getdata['reviews'];   
			?>
			<tbody>
				<tr>
					<td class="col-md-2 col-sm-6 col-xs-6"><img src="assets/images/menu/<?php echo $wish_item['hinhanh']; ?>" alt="imga"></td>
					<td class="col-md-7 col-sm-6 col-xs-6">
						<div class="product-name"><a href="index.php?quanly=item&id=<?php echo $wish_item['id']; ?>">
							<?php echo $wish_item['tensanpham']; ?>
						</a></div>
						<div class='rating-stars'>
								<ul id='stars'>
									<?php 
										for($j=1; $j<=5; $j++){
									?>
									<li class='star <?php if($star >= $j) echo 'hover'; ?>' data-value='<?php echo $j ?>' data-product_id="<?php echo $row_item['id_sanpham'] ?>">
										<i class='fa fa-star fa-fw'></i>
									</li>
									<?php 
										}
									?>
								</ul>
							</div>
						<div class="reviews">
							(<?php echo $count; ?> Đánh giá)
						</div>
						<div class="price">
							<?php echo number_format($wish_item['giasp'],0,',','.').' VND' ?>
						</div>
					</td>
					<td class="col-md-2 ">
					<form action="page/main/settle.php?idsanpham=<?php echo $wish_item['id'] ?>" method="POST">
						<input type="hidden" value="1" name="quantity">
						<button type="submit" class="btn-upper btn btn-primary" name="addtocart">THÊM GIỎ HÀNG</button>
					</form>
					</td>
					<td class="col-md-1 close-btn">
						<a href="page/main/settle.php?xoa=<?php echo $wish_item['id'] ?>" class=""><i class="fa fa-times"></i></a>
					</td>
				</tr>
			</tbody>
				<?php }} ?>
		</table>
	</div>
</div>			</div><!-- /.row -->
		</div><!-- /.sigin-in-->
		