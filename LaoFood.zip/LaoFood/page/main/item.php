<div class="breadcrumb">
    <div class="container">
        <div class="breadcrumb-inner">
            <ul class="list-inline list-unstyled">
                <li><a href="#">Home</a></li>
                <li class='active'>Menu</li>
            </ul>
        </div><!-- /.breadcrumb-inner -->
    </div><!-- /.container -->
</div><!-- /.breadcrumb -->
<div class="body-content outer-top-xs">
    <div class='container'>
        <div class='row single-product'>
            <div class='col-xs-12 col-sm-12 col-md-12'>
                <div class="detail-block">
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 gallery-holder">
                            <div class="product-item-holder size-big single-product-gallery small-gallery">
<?php
    $sql_item = "SELECT * FROM tbl_sanpham, tbl_danhmuc 
                WHERE tbl_sanpham.id_danhmuc=tbl_danhmuc.id_danhmuc AND tbl_sanpham.id_sanpham='$_GET[id]' LIMIT 1";
    $query_item = mysqli_query($connect, $sql_item);
    while($row_item = mysqli_fetch_array($query_item)){
        $id_sanpham = $row_item['id_sanpham'];
?>
                                <form action="page/main/settle.php?idsanpham=<?php echo $id_sanpham ?>" method="POST">
                                    <div id="owl-single-product">
                                        <div class="single-product-gallery-item">
                                            <a data-lightbox="image-1" data-title="Gallery"
                                                href="assets/images/menu/<?php echo $row_item['hinhanh']?>">
                                                <img class="img-responsive" alt="" src="assets/images/blank.gif"
                                                    data-echo="assets/images/menu/<?php echo $row_item['hinhanh']?>" />
                                            </a>
                                        </div><!-- /.single-product-gallery-item -->
                                    </div><!-- /.single-product-slider -->

                                    <div class="single-product-gallery-thumbs gallery-thumbs">

                                        <div id="owl-single-product-thumbnails">
                                            <div class="item">
                                                <a class="horizontal-thumb active" data-target="#owl-single-product"
                                                    data-slide="1" href="#slide1">
                                                    <img class="img-responsive" alt="" src="assets/images/blank.gif"
                                                        data-echo="assets/images/menu/<?php echo $row_item['hinhanh']?>" />
                                                </a>
                                            </div>
                                        </div><!-- /#owl-single-product-thumbnails -->
                                    </div><!-- /.gallery-thumbs -->

                            </div><!-- /.single-product-gallery -->
                        </div><!-- /.gallery-holder -->
                        <div class='col-sm-12 col-md-8 col-lg-8 product-info-block'>
                            <div class="product-info">
                                <h1 class="name"><?php echo $row_item['tensanpham'] ?></h1>
<?php 
    $sql_star = "SELECT ROUND(AVG(rating), 1) as star FROM tbl_review WHERE id_product=" . $id_sanpham;
    $query_star = mysqli_query($connect, $sql_star);
    $result_star = mysqli_fetch_array($query_star);
    $star = $result_star['star'];

    $query = "SELECT COUNT(*) AS reviews FROM tbl_review WHERE id_product = " . $id_sanpham;
    $result = mysqli_query($connect, $query);
    $getdata = mysqli_fetch_array($result);
    $count = $getdata['reviews'];
 ?>

                                <div class="rating-reviews m-t-20">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="pull-left">
                                                <div class='rating-stars text-center'>
                                                    <ul id='stars'>
                                                        <?php 
                                                            for($j=1; $j<=5; $j++){
                                                        ?>
                                                        <li class='star <?php if($star >= $j) echo 'hover'; ?>' data-value='<?php echo $j ?>' data-product_id="<?php echo $row_item['id_sanpham'] ?>">
                                                            <i class='fa fa-star fa-fw'></i>
                                                        </li>
                                                        <?php 
                                                            }
                                                        ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="pull-left">
                                                <div class="reviews">
                                                    <a href="#" class="lnk">(<?php echo $count; ?> Đánh giá)</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- /.row -->
                                </div><!-- /.rating-reviews -->

                                <div class="stock-container info-container m-t-10">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="pull-left">
                                                <div class="stock-box">
                                                    <span class="label">Tình trạng : </span>
                                                </div>
                                            </div>
                                            <div class="pull-left">
                                                <div class="stock-box">
                                                    <span class="value">
                                                        <?php if($row_item['tinhtrang']==1) echo 'Còn hàng'; else echo 'Đã hết hàng' ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- /.row -->
                                </div><!-- /.stock-container -->

                                <div class="description-container m-t-20">
                                    <p><?php echo $row_item['tomtat']; ?></p>
                                </div><!-- /.description-container -->

                                <div class="price-container info-container m-t-30">
                                    <div class="row">


                                        <div class="col-sm-6 col-xs-6">
                                            <div class="price-box">
                                                <span
                                                    class="price"><?php echo number_format($row_item['giasp'],0,',','.')." VND" ?></span>
                                            </div>
                                        </div>

                                        <div class="col-sm-6 col-xs-6">
                                            <div class="favorite-button m-t-5">
                                                <button class="btn btn-primary" data-toggle="tooltip" data-placement="right"
                                                    title="Ưa thích" name="addwishlist">
                                                    <i class="fa fa-heart"></i>
                                                </button>
                                                <a class="btn btn-primary" data-toggle="tooltip" data-placement="right"
                                                    title="Add to Compare" href="#">
                                                    <i class="fa fa-signal"></i>
                                                </a>
                                                <a class="btn btn-primary" data-toggle="tooltip" data-placement="right"
                                                    title="Liên hệ" href="index.php?quanly=contact">
                                                    <i class="fa fa-envelope"></i>
                                                </a>
                                            </div>
                                        </div>

                                    </div><!-- /.row -->
                                </div><!-- /.price-container -->

                                <div class="quantity-container info-container">
                                    <div class="row">

                                        <div class="qty">
                                            <span class="label">Số lượng :</span>
                                        </div>

                                        <div class="qty-count">
                                            <div class="cart-quantity">
                                            <style>
                                                input[type=number]::-webkit-inner-spin-button,
                                                input[type=number]::-webkit-outer-spin-button {
                                                opacity: 1;
                                                }
                                            </style>
                                                <div class="quant-input">
                                                    <input type="number" value="1" min="1" max="10" name="quantity">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="add-btn">
                                            <button type="submit" class="btn btn-primary" class="addtocart" name="addtocart" >
                                                <i class="fa fa-shopping-cart inner-right-vs"></i> THÊM GIỎ HÀNG
                                            </button>
                                        </div>
                                        </form>

                                    </div><!-- /.row -->
                                </div><!-- /.quantity-container -->
                            </div><!-- /.product-info -->
                        </div><!-- /.col-sm-7 -->
                    </div><!-- /.row -->
                </div>

                <div class="product-tabs inner-bottom-xs">
                    <div class="row">
                        <div class="col-sm-12 col-md-3 col-lg-3">
                            <ul id="product-tabs" class="nav nav-tabs nav-tab-cell">
                                <li class="active"><a data-toggle="tab" href="#description">NỘI DUNG SẢN PHẨM</a></li>
                                <li><a data-toggle="tab" href="#review">ĐÁNH GIÁ</a></li>
                                <li><a data-toggle="tab" href="#tags">TAGS</a></li>
                            </ul><!-- /.nav-tabs #product-tabs -->
                        </div>
                        <div class="col-sm-12 col-md-9 col-lg-9">

                            <div class="tab-content">

                                <div id="description" class="tab-pane in active">
                                    <div class="product-tab">
                                        <p class="text"><?php echo $row_item['noidung']; ?></p>
                                    </div>
                                </div><!-- /.tab-pane -->
<?php
    }
?>
                                <div id="review" class="tab-pane">
                                    <div class="product-tab">
<?php
    $sql_review = "SELECT * FROM tbl_review WHERE id_product='".$id_sanpham."' ORDER BY date DESC LIMIT 1";
    $query_review = mysqli_query($connect, $sql_review);
    while($row_review = mysqli_fetch_array($query_review)){
?>
                                        <div class="product-reviews">
                                            <h4 class="title">Đánh giá của khách hàng</h4>

                                            <div class="reviews">
                                                <div class="review">
                                                    <div class="review-title">
                                                        <h5><?php echo $row_review['username']; ?></h5>
                                                        <span class="summary"><?php echo $row_review['summary']; ?></span>
                                                        <span class="date"><i class="fa fa-calendar"></i>
                                                            <span><?php echo $row_review['date']; ?></span></span></div>
                                                    <div class="text">" <?php echo $row_review['review']; ?> "</div>
                                                </div>

                                            </div><!-- /.reviews -->
                                        </div><!-- /.product-reviews -->
<?php
    }
    if(isset($_POST['addreview'])) {
        $name = $_POST['username'];
        $summary = $_POST['summary'];
        $review = $_POST['review'];
        $rating = number_format($_POST['quality']+$_POST['price']+$_POST['value'])/3;
        $sql_addreview = "INSERT INTO tbl_review(id_product,username,rating,summary,review) 
                        VALUE('".$id_sanpham."','".$name."','".$rating."','".$summary."','".$review."')";
        $query_addreview = mysqli_query($connect, $sql_addreview);
        if($query_addreview) {
            echo '<script>alert("Bạn đã đánh giá thành công.")</script>';
        }
    }
?>
                                        <form class="cnt-form" method="POST" action="">
                                        <div class="product-add-review">
                                            <h4 class="title">Viết lời đánh giá của bạn</h4>
                                            <div class="review-table">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th class="cell-label">&nbsp;</th>
                                                                <th>1 sao</th>
                                                                <th>2 sao</th>
                                                                <th>3 sao</th>
                                                                <th>4 sao</th>
                                                                <th>5 sao</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td class="cell-label">Chất lượng</td>
                                                                <td><input type="radio" name="quality" class="radio" value="1"></td>
                                                                <td><input type="radio" name="quality" class="radio" value="2"></td>
                                                                <td><input type="radio" name="quality" class="radio" value="3"></td>
                                                                <td><input type="radio" name="quality" class="radio" value="4"></td>
                                                                <td><input type="radio" name="quality" class="radio" value="5" required></td>
                                                            </tr>
                                                            <tr>
                                                                <td class="cell-label">Giá cả</td>
                                                                <td><input type="radio" name="price" class="radio" value="1"></td>
                                                                <td><input type="radio" name="price" class="radio" value="2"></td>
                                                                <td><input type="radio" name="price" class="radio" value="3"></td>
                                                                <td><input type="radio" name="price" class="radio" value="4"></td>
                                                                <td><input type="radio" name="price" class="radio" value="5" required></td>
                                                            </tr>
                                                            <tr>
                                                                <td class="cell-label">Giá trị</td>
                                                                <td><input type="radio" name="value" class="radio" value="1"></td>
                                                                <td><input type="radio" name="value" class="radio" value="2"></td>
                                                                <td><input type="radio" name="value" class="radio" value="3"></td>
                                                                <td><input type="radio" name="value" class="radio" value="4"></td>
                                                                <td><input type="radio" name="value" class="radio" value="5" required></td>
                                                            </tr>
                                                        </tbody>
                                                    </table><!-- /.table .table-bordered -->
                                                </div><!-- /.table-responsive -->
                                            </div><!-- /.review-table -->

                                            <div class="review-form">
                                                <div class="form-container">

                                                        <div class="row">
                                                            <div class="col-sm-6">
                                                                <div class="form-group">
                                                                    <label for="exampleInputName">Tên <span class="astk">*</span></label>
                                                                    <input type="text" class="form-control txt" id="exampleInputName" name="username" required>
                                                                </div><!-- /.form-group -->
                                                                <div class="form-group">
                                                                    <label for="exampleInputSummary">
                                                                        Bản tóm tắt <span class="astk">*</span>
                                                                    </label>
                                                                    <input type="text" class="form-control txt" id="exampleInputSummary" name="summary" required>
                                                                </div><!-- /.form-group -->
                                                            </div>

                                                            <div class="col-md-6">
                                                                <div class="form-group">
                                                                    <label for="exampleInputReview">
                                                                        Lời đánh giá <span class="astk">*</span>
                                                                    </label>
                                                                    <textarea class="form-control txt txt-review" id="exampleInputReview" rows="4" name="review" required></textarea>
                                                                </div><!-- /.form-group -->
                                                            </div>
                                                        </div><!-- /.row -->

                                                        <div class="action text-right">
                                                            <button class="btn btn-primary btn-upper" name="addreview" type="submit"> 
                                                                GỬI BÌNH LUẬN
                                                            </button>
                                                        </div><!-- /.action -->

                                                </div><!-- /.form-container -->
                                            </div><!-- /.review-form -->

                                        </div><!-- /.product-add-review -->
                                        </form><!-- /.cnt-form -->
                                    </div><!-- /.product-tab -->
                                </div><!-- /.tab-pane -->

                                <div id="tags" class="tab-pane">
                                    <div class="product-tag">

                                        <h4 class="title">Product Tags</h4>
                                        <form class="form-inline form-cnt">
                                            <div class="form-container">

                                                <div class="form-group">
                                                    <label for="exampleInputTag">Add Your Tags: </label>
                                                    <input type="email" id="exampleInputTag" class="form-control txt">


                                                </div>

                                                <button class="btn btn-upper btn-primary" type="submit">ADD
                                                    TAGS</button>
                                            </div><!-- /.form-container -->
                                        </form><!-- /.form-cnt -->

                                        <form class="form-inline form-cnt">
                                            <div class="form-group">
                                                <label>&nbsp;</label>
                                                <span class="text col-md-offset-3">Use spaces to separate tags. Use
                                                    single quotes (') for phrases.</span>
                                            </div>
                                        </form><!-- /.form-cnt -->

                                    </div><!-- /.product-tab -->
                                </div><!-- /.tab-pane -->

                            </div><!-- /.tab-content -->
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.product-tabs -->


            </div><!-- /.col -->
            <div class="clearfix"></div>
        </div><!-- /.row -->