<div class="breadcrumb">
    <div class="container">
        <div class="breadcrumb-inner">
            <ul class="list-inline list-unstyled">
                <li><a href="#">Home</a></li>
                <li class='active'>Liên hệ</li>
            </ul>
        </div><!-- /.breadcrumb-inner -->
    </div><!-- /.container -->
</div><!-- /.breadcrumb -->

<div class="body-content">
    <div class="container">
        <div class="contact-page">
            <div class="row">

                <div class="col-md-12 contact-map outer-bottom-vs">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13570.97259436624!2d108.23931369714384!3d15.970695349786755!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3142108997dc971f%3A0x1295cb3d313469c9!2sVietnam%20-%20Korea%20University%20of%20Information%20and%20Communication%20Technology.!5e0!3m2!1sen!2s!4v1702522439960!5m2!1sen!2s"
                        width="600" height="450" style="border:0;"></iframe>
                </div>
                <div class="col-md-8 contact-form">
                    <form class="register-form" role="form">
                        <div class="col-md-12 contact-title">
                            <h4>Form Liên hệ</h4>
                        </div>
                        <div class="col-md-4 ">
                            <div class="form-group">
                                <label class="info-title" for="exampleInputName">Tên của bạn <span>*</span></label>
                                <input type="text" class="form-control unicase-form-control text-input"
                                    id="exampleInputName" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="info-title" for="exampleInputEmail1">Địa chỉ Email <span>*</span></label>
                                <input type="email" class="form-control unicase-form-control text-input"
                                    id="exampleInputEmail1" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="info-title" for="exampleInputTitle">Tiêu đề <span>*</span></label>
                                <input type="text" class="form-control unicase-form-control text-input"
                                    id="exampleInputTitle" placeholder="Tiêu đề" required>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="info-title" for="exampleInputComments">Bình luận của bạn
                                    <span>*</span></label>
                                <textarea class="form-control unicase-form-control" id="exampleInputComments"
                                    required></textarea>
                            </div>
                        </div>
                        <div class="col-md-12 outer-bottom-small m-t-20">
                            <button type="submit" class="btn-upper btn btn-primary checkout-page-button">Gửi Message</button>
                        </div>
                    </form>
                </div>
                <div class="col-md-4 contact-info">
                    <div class="contact-title">
                        <h4>Thông tin liên hệ</h4>
                    </div>
                    <div class="clearfix address">
                        <span class="contact-i"><i class="fa fa-map-marker"></i></span>
                        <span class="contact-span">
                            470 Đ. Trần Đại Nghĩa, Khu đô thị, Ngũ Hành Sơn, Đà Nẵng 550000, Vietnam
                        </span>
                    </div>
                    <div class="clearfix phone-no">
                        <span class="contact-i"><i class="fa fa-mobile"></i></span>
                        <span class="contact-span">+ (84) 0827 852 316<br>+ (856) 20 9575 5332</span>
                    </div>
                    <div class="clearfix email">
                        <span class="contact-i"><i class="fa fa-envelope"></i></span>
                        <span class="contact-span"><a href="#">laofood@gmail.com</a></span>
                    </div>
                </div>
            </div><!-- /.contact-page -->
        </div><!-- /.row -->