
<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<ul class="list-inline list-unstyled">
				<li><a href="#">Home</a></li>
				<li class='active'>Nội dung tin tức</li>
			</ul>
		</div><!-- /.breadcrumb-inner -->
	</div><!-- /.container -->
</div><!-- /.breadcrumb -->
<?php
	$sql_news = "SELECT * FROM blog WHERE id='$_GET[id]' LIMIT 1";
	$query_news = mysqli_query($connect, $sql_news);
	while($news = mysqli_fetch_array($query_news)){ 
?>
<div class="body-content">
	<div class="container">
		<div class="row">
			<div class="blog-page">
				<div class="col-xs-12 col-sm-12 col-md-12">
					<div class="blog-post wow fadeInUp">
	<img class="img-responsive" src="assets/images/blog-post/<?php echo $news['hinhanh'] ?>" style="height: 490px; width:1000px; margin: auto;">
	<h1><?php echo $news['tenbaiviet'] ?></h1>
	<span class="date-time"><?php echo $news['date'] ?></span>
	<p><?php echo $news['tomtat'] ?></p>
	<p><?php echo $news['noidung'] ?></p>
	<div class="social-media">
		<span>share post:</span>
		<a href="#"><i class="fa fa-facebook"></i></a>
		<a href="#"><i class="fa fa-twitter"></i></a>
		<a href="#"><i class="fa fa-linkedin"></i></a>
		<a href="#"><i class="fa fa-rss"></i></a>
		<a href="#" class="hidden-xs"><i class="fa fa-pinterest"></i></a>
	</div>
</div>
<?php } ?>
	<div class="row">
		<div class="col-md-12">
			<h4>Leave A Comment</h4>
		</div>
		<form class="register-form" role="form">
		<div class="col-md-4">
			
				<div class="form-group">
			    <label class="info-title" for="exampleInputName">Your Name <span>*</span></label>
			    <input type="text" class="form-control unicase-form-control text-input" id="exampleInputName" required>
			  </div>
		</div>
		<div class="col-md-4">
				<div class="form-group">
			    <label class="info-title" for="exampleInputEmail1">Địa chỉ email <span>*</span></label>
			    <input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail1"  required>
			  </div>
		</div>
		<div class="col-md-4">
				<div class="form-group">
			    <label class="info-title" for="exampleInputTitle">Tiểu đề <span>*</span></label>
			    <input type="text" class="form-control unicase-form-control text-input" id="exampleInputTitle"  required>
			  </div>
		</div>
		<div class="col-md-12">
				<div class="form-group">
			    <label class="info-title" for="exampleInputComments">Lời bình luận của bạn <span>*</span></label>
			    <textarea class="form-control unicase-form-control" id="exampleInputComments"  required></textarea>
			  </div>
		</div>
		<div class="col-md-12 outer-bottom-small m-t-20">
			<button type="submit" class="btn-upper btn btn-primary checkout-page-button">Submit Comment</button>
		</div>
			</form>
	</div>

<!-- ============================================== PRODUCT TAGS : END ============================================== -->					</div>
				</div>
			</div>
		</div>
	</div>
</div>
