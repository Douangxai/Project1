<?php
    session_start();
    include('../../connect.php');
    // thêm số lượng
    if(isset($_GET['cong'])){
        $id=$_GET['cong'];
        foreach($_SESSION['cart'] as $cart_item){
            if($cart_item['id']!=$id){
                $product[]=array('tensanpham'=>$cart_item['tensanpham'], 'id'=>$cart_item['id'], 'soluong'=>$cart_item['soluong'],'giasp'=>$cart_item['giasp'], 'hinhanh'=>$cart_item['hinhanh'], 'category'=>$cart_item['category']);
                $_SESSION['cart'] = $product;
            } else {
                $tangsoluong = $cart_item['soluong'] + 1;
                if($cart_item['soluong']<10){
                    $product[]=array('tensanpham'=>$cart_item['tensanpham'], 'id'=>$cart_item['id'], 'soluong'=>$tangsoluong,'giasp'=>$cart_item['giasp'], 'hinhanh'=>$cart_item['hinhanh'], 'category'=>$cart_item['category']);  
                } else {
                    $product[]=array('tensanpham'=>$cart_item['tensanpham'], 'id'=>$cart_item['id'], 'soluong'=>$cart_item['soluong'],'giasp'=>$cart_item['giasp'], 'hinhanh'=>$cart_item['hinhanh'], 'category'=>$cart_item['category']);
                }
                $_SESSION['cart'] = $product;
            }
        }
        header('Location:../../index.php?quanly=cart');
    }
    // trừ số lượng
    if(isset($_GET['tru'])){
        $id=$_GET['tru'];
        foreach($_SESSION['cart'] as $cart_item){
            if($cart_item['id']!=$id){
                $product[]=array('tensanpham'=>$cart_item['tensanpham'], 'id'=>$cart_item['id'], 'soluong'=>$cart_item['soluong'],'giasp'=>$cart_item['giasp'], 'hinhanh'=>$cart_item['hinhanh'], 'category'=>$cart_item['category']);
                $_SESSION['cart'] = $product;
            } else {
                $tangsoluong = $cart_item['soluong'] - 1;
                if($cart_item['soluong']>1){
                    $product[]=array('tensanpham'=>$cart_item['tensanpham'], 'id'=>$cart_item['id'], 'soluong'=>$tangsoluong,'giasp'=>$cart_item['giasp'], 'hinhanh'=>$cart_item['hinhanh'], 'category'=>$cart_item['category']);  
                } else {
                    $product[]=array('tensanpham'=>$cart_item['tensanpham'], 'id'=>$cart_item['id'], 'soluong'=>$cart_item['soluong'],'giasp'=>$cart_item['giasp'], 'hinhanh'=>$cart_item['hinhanh'], 'category'=>$cart_item['category']);
                }
                $_SESSION['cart'] = $product;
            }
        }
        header('Location:../../index.php?quanly=cart');
    }
    // xoá sản phẩm từ giỏ hàng
    if(isset($_SESSION['cart']) && isset($_GET['del'])){
        $id=$_GET['del'];
        foreach($_SESSION['cart'] as $cart_item){
            if($cart_item['id']!=$id){
                $product[]=array('tensanpham'=>$cart_item['tensanpham'], 'id'=>$cart_item['id'], 'soluong'=>$cart_item['soluong'],'giasp'=>$cart_item['giasp'], 'hinhanh'=>$cart_item['hinhanh'], 'category'=>$cart_item['category']);
            }
            $_SESSION['cart'] = $product;
            header('Location:../../index.php?quanly=cart');
        }
    }
    // xóa tất cả
    if(isset($_GET['delete'])&&$_GET['delete']==1){
        unset($_SESSION['cart']);
        header('Location:../../index.php?quanly=cart');
    }
    // thêm sản phẩm vào giỏ hàng
    if(isset($_POST['addtocart'])){
      //  session_destroy();
        $id=$_GET['idsanpham'];
        $soluong=$_POST['quantity'];
        $sql = "SELECT * FROM tbl_sanpham WHERE id_sanpham='".$id."'LIMIT 1";
        $query = mysqli_query($connect, $sql);
        $row = mysqli_fetch_array($query);
        if($row) {
            //tạo mảng product mới khi chưa thêm sản phẩm vào giỏ hàng
            $new_product = array(
                'tensanpham' => $row['tensanpham'],
                'id' => $id,
                'soluong' => $soluong,
                'giasp' => $row['giasp'],
                'hinhanh' => $row['hinhanh'],
                'category' => $row['category']
            ); // kiểm tra session giỏ hàng tôn tại

            $product = array(); // Khởi tạo mảng product bên ngoài vòng lặp
          
            if(isset($_SESSION['cart'])){
                $found = false;
                foreach($_SESSION['cart'] as $cart_item){
                    // dùng vòng lặp để kiểm tra sản phẩm đã tồn tại trong giỏ hàng hay chưa bằng id của sản phẩm
                    if($cart_item['id'] == $id) {
                        //SẢN PHẨM NÀY ĐÃ ĐƯỢC THÊM
                        $cart_item['soluong'] += $soluong; // Cập nhật số lượng sản phẩm trùng
                        $product[] = $cart_item;
                        $found = true;
                    } else {

                        // nếu chưa có sản phẩm sẽ dùng biến tạm product[] để lưu lại những sản phẩm đã lưu đã tòn tại trong giỏ hàng
                        $product[] = $cart_item;
                      }
                }
                if($found == false){
                    // nếu sản phẩm chưa được thêm vào giỏ hàng thì mình sẽ add new_product vào  $_SESSION['cart'][]                 
                    $_SESSION['cart'][] = $new_product;
                } else {
                    $_SESSION['cart'] = array_merge($product);
                }
            } else {
                $_SESSION['cart'] = array($new_product);
            }
        }
        header('Location:../../index.php?quanly=cart');
     }
     // Xóa từ sản phẩm ưa thích
     if(isset($_SESSION['wishlist']) && isset($_GET['xoa'])){
        $id=$_GET['xoa'];
        foreach($_SESSION['wishlist'] as $wish_item){
            if($wish_item['id']!=$id){
                $product[]=array('tensanpham'=>$wish_item['tensanpham'], 'id'=>$wish_item['id'], 'giasp'=>$wish_item['giasp'], 'hinhanh'=>$wish_item['hinhanh']);
            }
            $_SESSION['wishlist'] = $product;
            header('Location:../../index.php?quanly=wishlist');
        }
    }
     // thêm vào sản phẩm ưa thích
     if(isset($_POST['addwishlist'])){
        //  session_destroy();
          $id=$_GET['idsanpham'];
          $sql = "SELECT * FROM tbl_sanpham WHERE id_sanpham='".$id."'LIMIT 1";
          $query = mysqli_query($connect, $sql);
          $row = mysqli_fetch_array($query);
          if($row) {
              $new_product=array(array('tensanpham'=>$row['tensanpham'], 'id'=>$id, 'hinhanh'=>$row['hinhanh'], 'giasp'=>$row['giasp']));
              // kiểm tra session giỏ hàng tôn tại
              if(isset($_SESSION['wishlist'])){
                  foreach($_SESSION['wishlist'] as $wish_item){
                      // nếu dữ liệu trung
                      if($wish_item['id'] == $id) {
                        header('Location:../../index.php?quanly=index');
                          echo "Đã có trên danh sách ưa thích";
                      } else {
                          // nếu dữ liệu không trung
                          $product[]=array('tensanpham'=>$wish_item['tensanpham'], 'id'=>$wish_item['id'], 'giasp'=>$wish_item['giasp'], 'hinhanh'=>$wish_item['hinhanh'], 'masp'=>$wish_item['masp']);
                      }
                  }
                    // liên kết dữ liệu new_product với product
                    $_SESSION['wishlist']=array_merge($product, $new_product);
              } else {
                  $_SESSION['wishlist'] = $new_product;
              }
          }
          header('Location:../../index.php?quanly=wishlist');
        }
// login
    if(isset($_POST['login'])) {
        $user = $_POST['Email1'];
        $pass = md5($_POST['Password1']);
        $sql_login = "SELECT * FROM account WHERE email='".$user."' AND pass='".$pass."'";
        $row_account = mysqli_query($connect, $sql_login);
        if(mysqli_num_rows($row_account)>0){
            while($account = mysqli_fetch_array($row_account)){
            $_SESSION['sign-in'] = $account['username'];
            $_SESSION['id_account'] = $account['id_account'];
            header("Location:../../index.php?quanly=cart");}
        } else {
            header("Location:../../index.php?quanly=sign-in");
            echo '<script>alert("Tài khoản hoặc Mật khẩu không đúng, vui lòng nhập lại.")</script>';
        }
    }
// sign up
    if(isset($_POST['sign-up'])) {
        $name = $_POST['fullname'];
        $email = $_POST['Email2'];
        $phone = $_POST['phone'];
        $password = md5($_POST['password']);
        $sql_account = "SELECT * FROM account WHERE email='".$email."'";
        $account = mysqli_query($connect, $sql_account);
        if(mysqli_num_rows($account)==0){
            if($_POST['password'] == $_POST['repassword']) {
                $sql_register = mysqli_query($connect, "INSERT INTO account(username,email,phone,pass) 
                VALUE ('".$name."','".$email."','".$phone."','".$password."')");
                if($sql_register) {
                    echo '<p style="color:green">Bạn đã đăng ký thành công</p>';
                    $_SESSION['sign-in'] = $name;
                    $_SESSION['id_account'] = mysqli_insert_id($connect);
                    header("Location:../../index.php?quanly=cart");
                }
            } else {
                header("Location:../../index.php?quanly=sign-in");
                echo '<script>alert("Nhập mật khẩu không đúng.")</script>';
            }
        } else {
            header("Location:../../index.php?quanly=sign-in");
            echo '<script>alert("Tài khoản này đã có.")</script>';
        }
    }

?>